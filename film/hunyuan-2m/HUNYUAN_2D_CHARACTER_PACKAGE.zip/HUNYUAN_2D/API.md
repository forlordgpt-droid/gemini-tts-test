# Integration API

Load the classic scripts in order; no server or module bundler is required:

```html
<script src="art.js"></script>
<script src="engine.js"></script>
<svg id="scene" viewBox="0 0 900 600"></svg>
<script>
const world = new HunyuanWorld2D();
const hugo = world.create({id:'Hugo', x:200, y:540, scale:0.9, view:'front'});
world.registerSeat('chair1', 550, 540);
hugo.walkTo([550,540], {duration:3});
hugo.wave();
function draw(seconds) {
  world.updateAt(seconds);
  document.querySelector('#scene').innerHTML = world.svgAt(seconds);
}
</script>
```

Coordinates are screen pixels (X right, Y down). Position Y is the foot ground level. Art local height is approximately 481 pixels. The host draws its own 2D background/furniture and determines layer order. Characters are sorted by ground Y for simple stage overlap.

## Commands

| Method | Meaning |
|---|---|
| `walkTo([x,y], {duration})`, `runTo(...)` | Straight travel, gait, destination stop; defaults to 120 / 240 screen px/s |
| `stop()` | Stop body travel at its current position |
| `sit('chair1')`, `sit()` | Travel to registered seat then sit; or sit at current position |
| `stand()` | Return from seated pose |
| `jump()` | Anticipation, arc and landing |
| `sleep()`, `wake()` | Recline and close eyes, then return upright |
| `wave()`, `pointAt(target)` | Gesture; point turns to the target side |
| `nod()`, `shakeHead()` | Independent head motion |
| `face('front')` | Select front / quarterRight / sideRight / back / sideLeft / quarterLeft; left/right aliases supported |
| `turnTo(target)`, `lookAt(target)` | Turn to target side or adjust gaze |
| `setEmotion('happy')` | Select one of ten named expressions |
| `talk(text,{duration,visemes})` | Silent rhythmic mouth or explicit mouth cues; text available on sampled pose |
| `approach(target)` | Walk to a 130-pixel horizontal separation |
| `faceCharacter(id)`, `waveTo(id)` | Convenience interaction helpers |
| `updateAt(t)`, `poseAt(t)`, `svgAt(t)` | Advance live time; sample pure pose; render vector markup |
| `serialize()` | Serialize actor configuration, event tracks and current time |
| `Hunyuan2D.restore(json, world)` | Rebuild a saved actor; add it to `world.characters` yourself |
| `reset()` | Remove tracks and reset time; resolve outstanding promises as cancelled |

Targets accept an X number, `[x,y]`, `{x,y}`, or a registered seat/character ID. `face` accepts named 2D views, not 3D radians. Movement is straight-line, not obstacle routing. Supplied travel durations must stay within supported stride speed for the character scale; overly fast travel raises an error rather than stretching the legs.

Most commands return promises fulfilled when `updateAt()` reaches their end time. Keep the host animation loop running when awaiting an action. Deterministic offline rendering should schedule tracks first and then sample time. Calling `poseAt()`/`svgAt()` alone does not resolve promises.

## Layered simultaneous performance

Body, view, gesture, head, gaze, emotion and speech are separate channels. The latest event that has started on each channel controls that channel. Use a new view event to override walking's automatic side-facing view. Separate characters have independent event arrays and state.

```js
hugo.setEmotion('confused');
hugo.walkTo([650,540], {duration:4});
hugo.talk('What happened?', {
  duration:2,
  visemes:[
    {time:0, mouth:'closed'},
    {time:0.15, mouth:'O'},
    {time:0.4, mouth:'wide'},
    {time:0.65, mouth:'open'},
    {time:1.7, mouth:'closed'}
  ]
});
```

Cue times are relative to speech start. Mouth names: `closed`, `open`, `wide`, `O`. These are stylized mouth shapes, not an automatically generated phoneme track.

## Deterministic sequence

```js
hugo.add('body','walk',{to:{x:500,y:540}},0,3);
hugo.add('view','view',{view:'sideRight'},0,0);
hugo.add('body','sit',{to:{x:500,y:540}},3,1);
hugo.add('gesture','wave',{},4.3,2.2);
hugo.add('emotion','emotion',{emotion:'happy'},4.3,0);
// Always add future events in chronological order so their starting snapshots are correct.
for(let frame=0;frame<180;frame++) {
  const svg = HunyuanArt.svg(hugo.svgAt(frame/30),900,600);
  // Host exports/composites this SVG into its 2D movie system.
}
```

`add()` is an advanced API. Schedule events chronologically; adding an earlier event after a later event does not recompile that later event's captured starting state. Foot planting was numerically checked within supported steady straight travel, not all start/stop transitions, sloped floors or arbitrary choreography.

## State restoration

```js
const saved = hugo.serialize();
const restored = Hunyuan2D.restore(saved, world);
world.characters[restored.id] = restored;
const identicalFrame = restored.svgAt(2.4);
```

This preserves a character timeline. World furniture, custom backgrounds and active external audio are host responsibilities and are not included in the actor JSON.
