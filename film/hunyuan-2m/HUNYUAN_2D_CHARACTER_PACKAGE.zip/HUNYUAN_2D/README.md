# Hunyuan 2D — current-appearance edition

Only Hunyuan is included. This package contains **native 2D vector artwork and a 2D animation engine**. There are no 3D character files, 3D meshes, WebGL or Three.js dependencies.

## Open it

1. Extract the ZIP.
2. Double-click `index.html` (or `START_WINDOWS.bat`).
3. Choose an action, view or expression. Use Play/Pause, Restart and the timeline slider.
4. Choose Two independent to verify that separate copies can perform different actions.
5. Export an editable SVG, transparent PNG, animation state JSON or a PNG sprite sheet with timing metadata.

The demo works directly from disk and makes no internet requests. No Node.js installation is needed for playback. Node.js is only needed to run the optional developer tests and regenerate the static SVG exports.

## Character identity

The yellow beanie, swept brown hair, pale face, light hoodie with pocket and drawstrings, black gloves, thin black legs and dark sneakers follow the supplied Hunyuan character and its illustrated reference sheet. This is a vector reinterpretation preserving that design, not a pixel-identical tracing of the 3D render. It uses flat illustrated fills and outlines.

Six views: front, three-quarter right, right profile, back, left profile and three-quarter left. Left views mirror the right artwork, including hair asymmetry. Turns step through these drawn views; there is no unrestricted 3D rotation.

## Included controls

- Idle/breathing and deterministic blinking.
- Walking/running with moving roots, articulated two-link legs and planted stance feet during supported straight travel.
- Jump and landing; sitting and standing with a seat anchor.
- Wave, point, nod, shake head, gaze and named-view turns.
- Reclining sleep and wake.
- Ten expressions: neutral, happy, sad, angry, afraid, surprised, confused, disgusted, crying, laughing.
- Four controllable mouth shapes; timed mouth cues or a simple rhythmic talking animation.
- Independent copies, named target/seat lookup, approach and greeting helpers.
- Absolute-time evaluation, state serialization/restoration, transparent vector/raster exports.

## Files to edit

- `art.js`: actual layered vector path artwork and palette. Groups identify head, torso, limbs, gloves and sneakers.
- `engine.js`: 2D joints, motion, facial state and timeline.
- `studio.js`: demonstration controls; no story-specific movie is included.
- `assets/Hunyuan_*.svg`: editable, transparent illustrations of the six views.
- `assets/Hunyuan_MODEL_SHEET.svg`: arranged model sheet.
- `assets/RIG.json`: coordinate/anchor documentation, not a live configuration loader.
- `API.md`: integration examples and feature limits.
- `tests/`: actual automated results and runnable Node tests.

Editing an exported static SVG does not automatically update the procedural artwork. Change `art.js` to modify the live character and run `node export-assets.cjs` to regenerate the static exports.

## Important limits

This retains the main visible actions and facial controls; it is not a drop-in replacement for every 3D-engine feature. It has no depth camera, navigation/pathfinding, collision avoidance, seat reservation, cloth simulation, per-finger rig or automatic prop grasp solver. Hosts must stage multiple characters, furniture, props and occlusion. Sleep/wake is a stylized pose transition, not a bed-contact simulation. Extreme custom choreography needs review.

Talking is **silent mouth animation**, not generated speech. A host can supply audio and timed mouth cues. No phoneme detection, speech recognition or TTS service is bundled. There is no MP4 recorder; this is a character engine, not the earlier movie/export project.

## Validation

Run `node tests/engine.test.cjs` for state, motion and export-content checks. The included browser report records the actual local-file Chrome tests of every demo action, independent actors, seeking, downloads and absence of network requests. See `QC_REPORT.json` for the precise scope. Windows batch execution was not tested here; opening the same HTML file directly avoids the launcher dependency.
