/* Standalone deterministic 2D animation engine. Pixels, X right, Y down. */
(function(G){'use strict';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v)},mix=(a,b,t)=>a+(b-a)*t;
const VIEWS=['front','quarterRight','sideRight','back','sideLeft','quarterLeft'];
const EMOTIONS=['neutral','happy','sad','angry','afraid','surprised','confused','disgusted','crying','laughing'];
function ik(h,f,l1=80,l2=80,bend=1){const dx=f[0]-h[0],dy=f[1]-h[1],d=Math.max(.001,Math.hypot(dx,dy)),q=Math.min(d,l1+l2-.001),a=(l1*l1-l2*l2+q*q)/(2*q),b=Math.sqrt(Math.max(0,l1*l1-a*a));return[h,[h[0]+a*dx/d+b*dy/d*bend,h[1]+a*dy/d-b*dx/d*bend],f];}
class Hunyuan2D{
 constructor({id='Hunyuan',x=300,y=520,scale=1,view='front',world=null}={}){if(!VIEWS.includes(view))throw Error('Unknown 2D view');this.id=id;this.initial={x,y,scale,view};this.world=world;this.events=[];this.time=0;this.waiters=[];this.seq=0;}
 target(t){if(typeof t==='number')return{x:t,y:this.poseAt(this.time).y};if(Array.isArray(t)&&t.length===2&&t.every(Number.isFinite))return{x:t[0],y:t[1]};if(t&&Number.isFinite(t.x)&&Number.isFinite(t.y))return t;if(typeof t==='string'){const a=this.world?.characters[t];if(a){const p=a.poseAt(this.time);return{x:p.x,y:p.y}}const s=this.world?.seats[t];if(s)return s;}throw Error('Target must be [x,y], x, {x,y}, or a registered character/seat ID.');}
 add(channel,type,options={},start=this.time,duration=0){if(!Number.isFinite(start)||!Number.isFinite(duration)||duration<0)throw Error('Invalid event time');const p=this.poseAt(start);const e={channel,type,start,duration,order:this.seq++,from:{x:p.x,y:p.y,view:p.view,offset:p.offset,recline:p.recline},...structuredClone(options)};this.events.push(e);this.events.sort((a,b)=>a.start-b.start||a.order-b.order);return e;}
 done(end,channel="body"){return new Promise(resolve=>this.waiters.push({end,resolve,channel}));}
 updateAt(t){if(!Number.isFinite(t)||t<0)throw Error('Time must be non-negative');this.time=t;const ready=this.waiters.filter(w=>t>=w.end);this.waiters=this.waiters.filter(w=>t<w.end);for(const w of ready)w.resolve({cancelled:false});return this.poseAt(t);}
 reset(){for(const w of this.waiters)w.resolve({cancelled:true});this.waiters=[];this.events=[];this.time=0;this.seq=0;}
 move(type,target,{duration,start=this.time}={}){const to=this.target(target),p=this.poseAt(start);duration=duration??Math.hypot(to.x-p.x,to.y-p.y)/(type==='run'?240:120);if(!Number.isFinite(duration)||duration<=0)throw Error('Travel duration must be positive');if(Math.hypot(to.x-p.x,to.y-p.y)/duration/this.initial.scale>(type==='run'?500:220))throw Error('Travel is too fast for this scale; increase duration.');this.add('body',type,{to},start,duration);this.add('view','view',{view:to.x<p.x?'sideLeft':'sideRight'},start,0);return this.done(start+duration);}
 walkTo(t,o){return this.move('walk',t,o)}runTo(t,o){return this.move('run',t,o)}
 stop(){const p=this.poseAt(this.time);this.add('body','idle',{to:{x:p.x,y:p.y},holdOffset:p.offset},this.time,0);for(const w of this.waiters.filter(w=>w.channel==='body'))w.resolve({cancelled:true});this.waiters=this.waiters.filter(w=>w.channel!=='body');}
 sit(target=null){const now=this.time,to=target===null?this.target(this.poseAt(now)):this.target(target);let start=now;const p=this.poseAt(now),d=Math.hypot(to.x-p.x,to.y-p.y);if(d>1){const dur=d/120;this.add('body','walk',{to},start,dur);this.add('view','view',{view:to.x<p.x?'sideLeft':'sideRight'},start);start+=dur;}this.add('body','sit',{to,seatId:typeof target==='string'?target:null},start,1);return this.done(start+1);}
 stand(){this.add('body','stand',{},this.time,.9);return this.done(this.time+.9)}
 jump(){this.add('body','jump',{},this.time,1.25);return this.done(this.time+1.25)}
 sleep(){this.add('body','sleep',{},this.time,1);return this.done(this.time+1)}
 wake(){this.add('body','stand',{},this.time,1);return this.done(this.time+1)}
 wave(){this.add('gesture','wave',{},this.time,2.2);return this.done(this.time+2.2,"gesture")}
 pointAt(target){this.turnTo(target);const p=this.target(target),me=this.poseAt(this.time);this.add('gesture','point',{direction:p.x<me.x?-1:1},this.time,2);return this.done(this.time+2,"gesture")}
 nod(){this.add('head','nod',{},this.time,1.2);return this.done(this.time+1.2,"head")}
 shakeHead(){this.add('head','shake',{},this.time,1.2);return this.done(this.time+1.2,"head")}
 face(view){const aliases={left:'sideLeft',right:'sideRight'};view=aliases[view]||view;if(!VIEWS.includes(view))throw Error('Use a named 2D view');this.add('view','view',{view},this.time,.65);return this.done(this.time+.65,"view")}
 turnTo(target){const p=this.target(target),me=this.poseAt(this.time);return this.face(p.x<me.x?'sideLeft':'sideRight')}
 lookAt(target){const p=this.target(target),me=this.poseAt(this.time);this.add('gaze','gaze',{gaze:clamp((p.x-me.x)/25,-6,6)},this.time,.3);return this.done(this.time+.3,"gaze")}
 setEmotion(emotion){if(!EMOTIONS.includes(emotion))throw Error('Unknown expression');this.add('emotion','emotion',{emotion},this.time,0);return Promise.resolve({cancelled:false})}
 talk(text,{duration=3,visemes=[]}={}){if(typeof text!=='string'||duration<=0)throw Error('Text and positive duration required');if(visemes.some(v=>!Number.isFinite(v.time)||!['closed','open','wide','O'].includes(v.mouth)))throw Error('Invalid mouth cue');this.add('speech','talk',{text,visemes},this.time,duration);return this.done(this.time+duration,"speech")}
 approach(target){const q=this.target(target),p=this.poseAt(this.time);return this.walkTo([q.x+(p.x<q.x?-1:1)*130,q.y])}
 faceCharacter(t){return this.turnTo(t)}waveTo(t){this.turnTo(t);return this.wave()}
 serialize(){return JSON.stringify({schema:'hunyuan-2d/1',id:this.id,initial:this.initial,events:this.events,time:this.time});}
 static restore(json,world=null){const d=typeof json==='string'?JSON.parse(json):json;if(d.schema!=='hunyuan-2d/1')throw Error('Unsupported state schema');const c=new Hunyuan2D({id:d.id,...d.initial,world});c.events=structuredClone(d.events);c.time=d.time;c.seq=Math.max(0,...c.events.map(e=>e.order+1));return c;}
 poseAt(t){const selected={};for(const e of this.events)if(e.start<=t)selected[e.channel]=e;const b=selected.body;let x=this.initial.x,y=this.initial.y,offset=0,action='idle',phase=0,recline=0;
 if(b){const u=clamp((t-b.start)/(b.duration||1));x=b.from.x;y=b.from.y;action=b.type;
 if(b.type==='walk'||b.type==='run'){x=mix(b.from.x,b.to.x,u);y=mix(b.from.y,b.to.y,u);if(u>=1)action='idle';}
 if(b.type==='idle'){x=b.to.x;y=b.to.y;offset=b.holdOffset||0;}
 if(b.type==='sit'){x=b.to.x;y=b.to.y;offset=mix(b.from.offset,60,ease(u));}
 if(b.type==='stand'){offset=b.from.offset*(1-ease(u));recline=(b.from.recline||0)*(1-ease(u))||0;if(u>=1)action='idle';}
 if(b.type==='sleep'){offset=0;recline=-90*ease(u);}
 if(b.type==='jump'){const q=clamp((u-.15)/.72);y-=4*95*q*(1-q);offset=u<.15?18*Math.sin(u/.15*Math.PI/2):u>.87?16*Math.sin((u-.87)/.13*Math.PI):0;if(u>=1)action='idle';}
 }
 let view=this.initial.view;if(selected.view){const e=selected.view,u=clamp((t-e.start)/(e.duration||.001));let a=VIEWS.indexOf(e.from.view),z=VIEWS.indexOf(e.view),d=z-a;if(d>3)d-=6;if(d< -3)d+=6;view=VIEWS[(a+Math.round(d*ease(u))+6)%6];}
 const side=view.startsWith('side'),quarter=view.startsWith('quarter'),flip=view.endsWith('Left')?-1:1,width=side?.55:quarter?.8:1;
 const hipY=-160+offset;let legs=[[[ -23*width,hipY],[-23*width,-89+offset*.4],[-23*width,-20]],[[23*width,hipY],[23*width,-89+offset*.4],[23*width,-20]]],footAngles=[0,0];
 const moving=action==='walk'||action==='run';let speed=0;
 if(moving){const period=action==='run'?.52:.82,stance=action==='run'?.4:.6;speed=Math.hypot(b.to.x-b.from.x,b.to.y-b.from.y)/b.duration;const travel=speed/this.initial.scale,span=travel*period*stance;phase=(t-b.start)/period;
 for(let i=0;i<2;i++){const q=(phase+i*.5)%1;const lift=q<stance?0:(action==='run'?44:24)*Math.sin((q-stance)/(1-stance)*Math.PI);const fx=q<stance?span*(.5-q/stance):span*(-.5+(q-stance)/(1-stance));const h=[(i?1:-1)*23*width,hipY],f=[h[0]+fx,-20-lift];legs[i]=ik(h,f,80,80,1);footAngles[i]=q<stance?0:-10*Math.sin((q-stance)/(1-stance)*Math.PI);}
 }
 if(action==='sit'||(action==='stand'&&offset>.1)||(b?.type==='idle'&&offset>30)){const k=clamp(offset/60);for(let i=0;i<2;i++){const hx=(i?1:-1)*23*width;legs[i]=ik([hx,hipY],[mix(hx,65+(i?9:-9),k),-20],80,80,1);}}
 const breath=moving?0:Math.sin(t*2)*1.3;offset+=breath;
 const shoulders=[[-44*width,-284+offset],[44*width,-284+offset]],arms=shoulders.map((s,i)=>[s,[s[0]+(i?14:-14),-232+offset],[s[0]+(i?18:-18),-185+offset]]);
 if(moving)for(let i=0;i<2;i++){const a=Math.sin(phase*Math.PI*2+i*Math.PI)*(action==='run'?.85:.5),s=shoulders[i];arms[i]=[s,[s[0]+Math.sin(a)*53,s[1]+Math.cos(a)*53],[s[0]+Math.sin(a)*95,s[1]+Math.cos(a)*95]];}
 if(offset>35)for(let i=0;i<2;i++){const s=shoulders[i];arms[i]=[s,[s[0]+18,s[1]+48],[40+i*21,-110+offset*.08]];}
 let openHand=false;const g=selected.gesture;if(g&&t<g.start+g.duration){const u=(t-g.start)/g.duration,blend=Math.min(ease(u/.18),ease((1-u)/.18)),s=shoulders[1];let dest;if(g.type==='wave'){openHand=true;dest=[[s[0]+52,s[1]-30],[s[0]+55+Math.sin(u*Math.PI*10)*14,s[1]-92]];}else dest=[[s[0]+55,s[1]+3],[s[0]+108,s[1]+1]];for(let j=1;j<3;j++)arms[1][j]=arms[1][j].map((v,k)=>mix(v,dest[j-1][k],blend));}
 let headTilt=0,headNod=0,headOffset=0;const h=selected.head;if(h&&t<h.start+h.duration){const u=(t-h.start)/h.duration,w=Math.sin(u*Math.PI);if(h.type==='nod'){headNod=Math.sin(u*Math.PI*4)*7*w;headTilt=Math.sin(u*Math.PI*4)*3*w;}else headOffset=Math.sin(u*Math.PI*5)*9*w;}
 const speech=selected.speech&&t<selected.speech.start+selected.speech.duration?selected.speech:null;let mouth='closed';if(speech){const q=t-speech.start;if(speech.visemes.length){for(const v of [...speech.visemes].sort((a,b)=>a.time-b.time))if(v.time<=q)mouth=v.mouth;}else mouth=['closed','open','wide','O','open'][Math.floor(q*9)%5];}
 const blinkOffset=Array.from(this.id).reduce((a,c)=>a+c.charCodeAt(0),0)%17/7;const blink=((t+blinkOffset)%4.1)<.13||action==='sleep';const emotion=selected.emotion?.emotion||'neutral';
 return{id:this.id,x,y,recline,scale:this.initial.scale,view,emotion,blink,mouth,gaze:(selected.gaze?.gaze||0)*flip,headTilt,headNod,headOffset,offset,lean:moving?(action==='run'?7:2):0,legs,arms,footAngles,openHand,action,speech:speech?.text||'',phase,speed};
 }
 svgAt(t=this.time){return G.HunyuanArt.render(this.poseAt(t));}
}
class World2D{constructor(){this.characters={};this.seats={};this.time=0;}create(options={}){const id=options.id||'Hunyuan';if(this.characters[id])throw Error('Duplicate character ID');const c=new Hunyuan2D({...options,world:this});this.characters[id]=c;return c;}registerSeat(id,x,y){if(!Number.isFinite(x)||!Number.isFinite(y))throw Error('Seat uses pixel coordinates');this.seats[id]={x,y};}updateAt(t){this.time=t;for(const c of Object.values(this.characters))c.updateAt(t)}svgAt(t=this.time){return Object.values(this.characters).sort((a,b)=>a.poseAt(t).y-b.poseAt(t).y).map(c=>c.svgAt(t)).join('');}}
G.Hunyuan2D=Hunyuan2D;G.HunyuanWorld2D=World2D;G.Hunyuan2DViews=VIEWS;G.Hunyuan2DEmotions=EMOTIONS;
if(typeof module!=='undefined')module.exports={Hunyuan2D,World2D,VIEWS,EMOTIONS,ik};
})(typeof window!=='undefined'?window:globalThis);
