import * as THREE from 'three';
import gsap from 'gsap';
import {Output,Mp4OutputFormat,BufferTarget,CanvasSource,Quality} from 'mediabunny';

// Hunyuan 30s animated art-direction preview. No paid API or remote services.
// Every frame is sampled from an absolute movie clock; three independent image
// planes are real PerspectiveCamera objects, NOT a zoom on a flattened image.
const W=1920,H=1080,FPS=30,DURATION=30;
const shots=[
 {id:'S01',start:0,end:5,name:'THE MORNING',x0:-.58,x1:.46,y0:.07,y1:-.07,z0:10.25,z1:9.56,actor:[765,705,.63]},
 {id:'S02',start:5,end:10,name:'SMALL ROUTINES',x0:.58,x1:-.46,y0:-.04,y1:.05,z0:10.10,z1:9.42,actor:[990,720,.67]},
 {id:'S03',start:10,end:15,name:'BEFORE THE SIREN',x0:-.48,x1:.34,y0:.13,y1:-.07,z0:10.18,z1:9.45,actor:[792,755,.72]},
 {id:'S04',start:15,end:20,name:'THE SIREN',x0:.34,x1:-.48,y0:.10,y1:-.12,z0:10.05,z1:9.24,actor:[700,1000,.93]},
 {id:'S05',start:20,end:25,name:'THE PHONE',x0:-.28,x1:.45,y0:.07,y1:-.07,z0:10.05,z1:9.27,actor:[1030,995,.94]},
 {id:'S06',start:25,end:30,name:'EMERGENCY',x0:.32,x1:-.28,y0:.10,y1:-.04,z0:9.89,z1:9.16,actor:[1400,986,1.04]},
];
const canvas=document.getElementById('stage');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true,alpha:false});
renderer.setPixelRatio(1);renderer.setSize(W,H,false);renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.NoToneMapping;renderer.setClearColor(0x111830);
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(2*Math.atan(.45)*180/Math.PI,16/9,.1,100);
const camTracks=gsap.timeline({paused:true});
for(const sh of shots){
 camTracks.set(camera.position,{x:sh.x0,y:sh.y0,z:sh.z0},sh.start);
 camTracks.to(camera.position,{x:sh.x1,y:sh.y1,z:sh.z1,duration:sh.end-sh.start,ease:'power2.inOut'},sh.start);
}
const plane=(map,z,width,order)=>{const mat=new THREE.MeshBasicMaterial({map,transparent:true,depthWrite:false,depthTest:false,toneMapped:false,side:THREE.DoubleSide});const mesh=new THREE.Mesh(new THREE.PlaneGeometry(width,width*9/16),mat);mesh.position.z=z;mesh.renderOrder=order;scene.add(mesh);return mesh;};
function canvasTex(c){const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.minFilter=THREE.LinearFilter;return tex;}
const imgs=[];
async function loadImg(src){const img=new Image();img.src=src;await img.decode();return img;}
for(let i=0;i<6;i++)imgs.push(await Promise.all(['far','mid','front'].map(k=>loadImg(`assets/${k}_${i}.${k==='far'?'jpg':'webp'}`))));
const layers=[
 {z:-3.5,width:23.5,order:0},
 {z:-.5,width:19.9,order:1},
 {z:2.1,width:17.15,order:4}
];
const layerMeshes=layers.map(({z,width,order})=>{
 const c=document.createElement('canvas');c.width=W;c.height=H;
 const ctx=c.getContext('2d',{alpha:true});return {canvas:c,ctx,mesh:plane(canvasTex(c),z,width,order)};
});
const actorCanvas=document.createElement('canvas');actorCanvas.width=W;actorCanvas.height=H;
const actx=actorCanvas.getContext('2d',{alpha:true});const aTex=canvasTex(actorCanvas);
const actorMesh=plane(aTex,.55,17.8,3);
const guiCanvas=document.createElement('canvas');guiCanvas.width=W;guiCanvas.height=H;
const g=guiCanvas.getContext('2d',{alpha:true});const guiTex=canvasTex(guiCanvas);
const guiMesh=plane(guiTex,3,11.2,8);
const actor=new window.Hunyuan2D({id:'Hunyuan',x:910,y:850,scale:.72,view:'quarterRight'});
// Chronological native event scheduling. Never re-add actions during frame capture.
actor.add('body','sleep',{},0,.05);
actor.add('emotion','emotion',{emotion:'neutral'},0,0);
actor.add('body','stand',{},15.05,1.4);
actor.add('view','view',{view:'quarterRight'},15.05,0);
actor.add('emotion','emotion',{emotion:'surprised'},15.5,0);
actor.add('gesture','point',{direction:1},21.1,1.6);
actor.add('emotion','emotion',{emotion:'confused'},22,0);
actor.add('emotion','emotion',{emotion:'afraid'},25,0);
actor.add('head','shake',{},26.1,1.4);
const FRAME_WIDTH=1376,FRAME_HEIGHT=768;
let active=-1,serial=0;
async function loadShot(i){for(let j=0;j<3;j++){
 const layer=layerMeshes[j];layer.ctx.clearRect(0,0,W,H);layer.ctx.drawImage(imgs[i][j],0,0,W,H);layer.mesh.material.map.needsUpdate=true;
 } active=i;
}
function ease(x){return x*x*(3-2*x)}
function type(str,x,y,size=50,weight=750,color='#fff5e7',align='left'){
 g.font=`${weight} ${size}px Inter, 'Inter Display', system-ui, sans-serif`;g.textAlign=align;g.textBaseline='alphabetic';g.fillStyle=color;g.fillText(str,x,y);g.textAlign='left';
}
function pill(str,x,y,accent='#9bdddf'){
 g.save();g.fillStyle='rgba(14,28,53,.80)';g.strokeStyle=accent;g.lineWidth=3;g.beginPath();g.roundRect(x,y,Math.max(255,str.length*17+66),66,20);g.fill();g.stroke();type(str,x+30,y+44,26,800,accent);g.restore();
}
function graphics(i,t){
 g.clearRect(0,0,W,H);const sh=shots[i],u=t-sh.start,p=Math.min(1,Math.max(0,u/1.2)),q=ease(p);
 g.save();
 if(i===0){g.globalAlpha=Math.min(1,u*1.2,Math.max(0,(5-u)*2));pill('TUESDAY / 06:41',104,88,'#c9ebe7');
   g.strokeStyle='rgba(255,210,143,.28)';g.lineWidth=7;for(let j=0;j<12;j++){g.beginPath();g.arc(420,490,110+j*23,2.3,2.8);g.stroke();}
 }
 if(i===1){g.globalAlpha=Math.min(1,u*2,Math.max(0,(5-u)*2));
   // Steam drifts independently of camera and breakfast tabletop.
   for(let k=0;k<3;k++){const xx=390+k*36, yy=650-(u*32)%110;g.strokeStyle=`rgba(255,235,203,${.62-k*.12})`;g.lineWidth=9-k*2;g.beginPath();g.moveTo(xx,yy);g.bezierCurveTo(xx-32,yy-65,xx+54,yy-112,xx+20,yy-165);g.stroke();}
   if(u>1&&u<3.8){pill('09:00  /  MEETING',1114,92,'#ffddac');}
 }
 if(i===2){g.globalAlpha=Math.min(1,u,Math.max(0,(5-u)*1.5));
   // A held visual beat and anticipation, not decoration on every word.
   pill('THE LAST NORMAL MORNING',94,96,'#f7d3af');
   for(let j=0;j<12;j++){const x=140+(j*149)%1580,y=200+(j*85)%660;g.fillStyle=`rgba(255,243,222,${.14+.13*Math.sin(t*2+j)})`;g.beginPath();g.arc(x+Math.sin(t+j)*18,y-t*5,2+j%3,0,6.28);g.fill();}
 }
 if(i===3){
   // Siren lights and directional wavefronts are baked into the rendered canvas.
   const pulse=(Math.sin(t*3.1)+1)/2;
   const grad=g.createLinearGradient(0,0,W,600);grad.addColorStop(0,`rgba(252,61,116,${.13+.25*pulse})`);grad.addColorStop(1,`rgba(30,223,255,${.17+.2*(1-pulse)})`);g.fillStyle=grad;g.fillRect(0,0,W,H);
   for(let k=0;k<4;k++){g.strokeStyle=k%2?'rgba(121,236,249,.52)':'rgba(251,120,190,.51)';g.lineWidth=11-k*2;g.beginPath();const cy=330+k*82+Math.sin(t*3+k)*28;g.moveTo(850,cy);g.bezierCurveTo(1120,cy-145,1370,cy+125,1930,cy-20);g.stroke();}
   g.globalAlpha=Math.min(1,u*2,Math.max(0,(5-u)*1.4));pill('SIREN DETECTED',96,87,'#ffc6d4');
 }
 if(i===4){const cx=1537+Math.sin(t*29)*8,cy=790;for(let k=0;k<4;k++){
   const r=55+k*65+(u*53)%67;g.lineWidth=7-k;g.strokeStyle=`rgba(255,109,99,${.52-k*.09})`;g.beginPath();g.arc(cx,cy,r,0,6.283);g.stroke();}
   if(u>.9)pill('NOT A TEST',88,90,'#ffcbb3');
 }
 if(i===5){
   g.save();g.translate(392+Math.sin(t*18)*4,570);g.rotate(-.038);
   g.shadowColor='rgba(225,56,69,.42)';g.shadowBlur=60;
   g.fillStyle='#171e34';g.strokeStyle='#9fb6c2';g.lineWidth=19;g.beginPath();g.roundRect(-305,-455,610,920,76);g.fill();g.stroke();g.shadowBlur=0;
   g.fillStyle='#c72c42';g.beginPath();g.roundRect(-268,-389,536,790,30);g.fill();
   g.strokeStyle='rgba(255,212,213,.55)';g.lineWidth=4;g.strokeRect(-228,-142,456,2);
   type('EMERGENCY',-225,-200,61,900);type('ALERT',-225,-125,66,900);
   type('MISSILE THREAT',-217,27,42,800);type('INBOUND',-217,88,51,800);
   type('SEEK SHELTER',-217,183,36,800);type('IMMEDIATELY',-217,230,36,800);
   g.restore();
   // Thin signal accents plus smaller, carefully spaced title hierarchy.
   const v=Math.max(0,Math.min(1,(u-1)/1.8));g.strokeStyle=`rgba(255,79,101,${.45+.38*v})`;g.lineWidth=12;
   for(let k=0;k<3;k++){g.beginPath();g.arc(1370,350,136+k*58+v*60,Math.PI*1.14,Math.PI*1.84);g.stroke();}
   pill('TAKE ACTION NOW',1080,83,'#ffc3bb');
 }
 g.restore();
}
async function characterAt(t,i){
 actx.clearRect(0,0,W,H);const p=actor.poseAt(t);
 const svg=window.HunyuanArt.svg(actor.svgAt(t),W,H);
 const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
 try{const im=await loadImg(url);const [x,y,scale]=shots[i].actor;
   actx.save();actx.translate(x,y);actx.scale(scale,scale);actx.translate(-910,-850);actx.drawImage(im,0,0,W,H);actx.restore();
 }finally{URL.revokeObjectURL(url)}
 aTex.needsUpdate=true;return p;
}
async function renderFrame(t){
 if(!Number.isFinite(t)||t<0||t>=DURATION)throw Error(`Outside 0–30s: ${t}`);
 const token=++serial;let i=shots.findIndex(s=>t>=s.start&&t<s.end);if(i<0)throw Error(`No shot at ${t}`);
 if(active!==i)await loadShot(i);
 camTracks.seek(t,false);camera.lookAt(0,0,0);
 const u=(t-shots[i].start)/(shots[i].end-shots[i].start);
 const breathe=Math.sin(t*1.5)*.018;
 // These are physically separate 3D picture planes at different Z depths.
 layerMeshes[0].mesh.position.x=Math.sin(t*.27)*.015;
 layerMeshes[1].mesh.position.x=Math.sin(t*.64+.3)*.055;
 layerMeshes[2].mesh.position.x=.11*Math.sin(t*1.25+.4)+Math.sin(u*Math.PI)*.13;
 layerMeshes[2].mesh.position.y=Math.sin(t*.92)*.024;
 // Emergency curtain floats physically faster than the distant city skyline.
 if(i===3)layerMeshes[2].mesh.position.x+=Math.sin(u*18)*.08;
 const pose=await characterAt(t,i);
 if(serial!==token)throw Error('Stale frame');
 actorMesh.position.x=0;actorMesh.position.y=breathe;
 graphics(i,t);guiTex.needsUpdate=true;
 guiMesh.position.x=camera.position.x;guiMesh.position.y=camera.position.y;
 renderer.render(scene,camera);
 return {t,shot:shots[i].id,pose:pose.action,cameraX:camera.position.x,cameraZ:camera.position.z};
}
await renderFrame(0);window.ready=true;window.renderFrame=renderFrame;
document.getElementById('status').textContent='Hunyuan 2D / first 30s / native-rig 2.5D preview';
window.exportShard=async function(start,end){
 if(!Number.isInteger(start)||start%10||start<0||start>=30||end!==start+10)throw Error('Use 10s sharded export at 0,10,20');
 const src=new CanvasSource(canvas,{codec:'avc',quality:new Quality({bitrate:8e6})});
 const output=new Output({format:new Mp4OutputFormat(),target:new BufferTarget()});
 output.addVideoTrack(src,{frameRate:FPS});await output.start();
 for(let f=0;f<300;f++){await renderFrame(start+f/FPS);await src.add(f/FPS,1/FPS)}
 await output.finalize();const buf=output.target.buffer;if(!buf||buf.byteLength<50000)throw Error('Empty MP4');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([buf],{type:'video/mp4'}));a.download=`part_${start/10}.mp4`;document.body.appendChild(a);a.click();a.remove();
 return {start,end,frames:300,bytes:buf.byteLength};
};
window.exportSfx=async()=>{
 const rate=24000,N=30*rate,offline=new OfflineAudioContext(1,N,rate),master=offline.createGain();master.gain.value=.095;master.connect(offline.destination);
 const tone=(at,len,from,to,amp,shape)=>{const osc=offline.createOscillator(),gain=offline.createGain();osc.type=shape;osc.frequency.setValueAtTime(from,at);osc.frequency.exponentialRampToValueAtTime(Math.max(to,1),at+len);gain.gain.setValueAtTime(.0001,at);gain.gain.linearRampToValueAtTime(amp,at+.18);gain.gain.exponentialRampToValueAtTime(.0001,at+len);osc.connect(gain);gain.connect(master);osc.start(at);osc.stop(at+len);};
 tone(14,8.7,175,380,.3,'sawtooth');tone(16.4,6,310,150,.13,'triangle');tone(23.0,.6,630,290,.28,'square');tone(24.4,.6,630,290,.24,'square');tone(26,.8,770,380,.24,'square');
 const pcm=(await offline.startRendering()).getChannelData(0),wav=new ArrayBuffer(44+pcm.length*2),d=new DataView(wav),o=new Uint8Array(wav);
 const ss=(pos,s)=>{for(let j=0;j<s.length;j++)o[pos+j]=s.charCodeAt(j)};ss(0,'RIFF');d.setUint32(4,36+pcm.length*2,true);ss(8,'WAVE');ss(12,'fmt ');d.setUint32(16,16,true);d.setUint16(20,1,true);d.setUint16(22,1,true);d.setUint32(24,rate,true);d.setUint32(28,rate*2,true);d.setUint16(32,2,true);d.setUint16(34,16,true);ss(36,'data');d.setUint32(40,pcm.length*2,true);
 for(let i=0;i<pcm.length;i++)d.setInt16(44+i*2,Math.round(Math.max(-1,Math.min(1,pcm[i]))*32767),true);
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([wav],{type:'audio/wav'}));a.download='sfx_30.wav';document.body.appendChild(a);a.click();a.remove();return {seconds:30,bytes:wav.byteLength};
};
let raf=null,epoch=0;
document.getElementById('play').onclick=()=>{if(raf!==null)return;epoch=performance.now();const next=async now=>{if(raf===null)return;try{await renderFrame(((now-epoch)/1000)%30)}catch(e){document.getElementById('status').textContent=e.message;raf=null;return}raf=requestAnimationFrame(next)};raf=requestAnimationFrame(next)};
document.getElementById('pause').onclick=()=>{if(raf!==null)cancelAnimationFrame(raf);raf=null};
