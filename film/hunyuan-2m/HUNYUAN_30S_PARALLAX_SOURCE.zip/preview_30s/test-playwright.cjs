const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=__dirname,PORT=8474,SHARD=Number(process.env.SHARD_INDEX),SFX=process.env.EXPORT_SFX==='1';
if(!SFX&&(!Number.isInteger(SHARD)||SHARD<0||SHARD>2))throw Error('Expected SHARD_INDEX 0, 1 or 2');
const MIME={'.html':'text/html','.js':'application/javascript','.jpg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.json':'application/json'};
const server=http.createServer((req,res)=>{try{const u=new URL(req.url,`http://127.0.0.1:${PORT}`),p=u.pathname==='/'?'/index.html':u.pathname;const full=path.resolve(ROOT,'.'+decodeURIComponent(p));if(!full.startsWith(ROOT+path.sep))throw Error('path');const b=fs.readFileSync(full);res.writeHead(200,{'content-type':MIME[path.extname(full)]||'application/octet-stream'});res.end(b)}catch(e){res.writeHead(404);res.end('missing')}});
(async()=>{await new Promise(r=>server.listen(PORT,'127.0.0.1',r));const browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-unsafe-swiftshader']});const page=await browser.newPage({viewport:{width:1920,height:1080},acceptDownloads:true});const errors=[];
page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
try{await page.goto(`http://127.0.0.1:${PORT}/`);await page.waitForFunction(()=>window.ready===true,null,{timeout:60000});const out=path.join(ROOT,'qc');fs.mkdirSync(out,{recursive:true});
 if(SFX){const wait=page.waitForEvent('download',{timeout:120000});const d=await page.evaluate(()=>window.exportSfx());const f=await wait;await f.saveAs(path.join(out,'original_sfx_30s.wav'));if(d.seconds!==30)throw Error('SFX bad length');console.log('PASS 30-second WebAudio soundtrack',d);}
 else{
  const start=SHARD*10,canvas=page.locator('#stage');
  const sampling=[.5,2.5,4.5,5.5,7.5,9.5].map(x=>start+x).filter(x=>x<30);
  for(let k=0;k<sampling.length;k++){
   const t=sampling[k],metadata=await page.evaluate(x=>window.renderFrame(x),t);
   await canvas.screenshot({path:path.join(out,`at_${String(t).replace('.','_')}.png`)});
   if(Math.abs(metadata.cameraX)<.001&&Math.abs(metadata.cameraZ-10)<.001)throw Error('No camera animation '+t);
   console.log('CAMERA KEYFRAME',JSON.stringify(metadata));
  }
  await page.evaluate(x=>window.renderFrame(x),start+1.3);const a=await canvas.screenshot();
  await page.evaluate(x=>window.renderFrame(x),start+6.3);
  await page.evaluate(x=>window.renderFrame(x),start+1.3);const b=await canvas.screenshot();
  if(!a.equals(b))throw Error('Absolute-time backwards seek is not deterministic');
  const pending=page.waitForEvent('download',{timeout:480000});const meta=await page.evaluate(x=>window.exportShard(x,x+10),start);const file=await pending;await file.saveAs(path.join(out,`part_${SHARD}.mp4`));
  if(meta.frames!==300||meta.bytes<100000)throw Error('Invalid rendered shard');console.log('PASS 10-second Hunyuan native-rig multiplane camera shard',meta);
 }
 if(errors.length)throw Error('Browser errors: '+errors.join('; '));
}finally{await browser.close();await new Promise(r=>server.close(r))}})().catch(e=>{console.error(e.stack);process.exitCode=1});
