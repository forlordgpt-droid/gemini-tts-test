import * as THREE from 'three';
import gsap from 'gsap';
import {Output, Mp4OutputFormat, BufferTarget, CanvasSource, Quality} from 'mediabunny';

// HUNYUAN / BUNKER — 120-second deterministic illustrated film.
// All motion is sampled at absolute story time; sharded runners produce identical joins.
const W=1920,H=1080,FPS=30,DURATION=120;
const beats=[
 {id:'B01',s:0,e:6,place:'BEDROOM',mood:'calm'},
 {id:'B02',s:6,e:14,place:'BEDROOM',mood:'calm'},
 {id:'B03',s:14,e:23,place:'BEDROOM',mood:'siren'},
 {id:'B04',s:23,e:33,place:'BEDROOM',mood:'alert'},
 {id:'B05',s:33,e:41,place:'PHONE',mood:'danger'},
 {id:'B06',s:41,e:48,place:'BEDROOM',mood:'fear'},
 {id:'B07',s:48,e:59,place:'BEDROOM',mood:'bias'},
 {id:'B08',s:59,e:70,place:'BEDROOM',mood:'countdown'},
 {id:'B09',s:70,e:78,place:'BEDROOM',mood:'decision'},
 {id:'B10',s:78,e:88,place:'STREET',mood:'chaos'},
 {id:'B11',s:88,e:99,place:'MAP',mood:'route'},
 {id:'B12',s:99,e:108,place:'FARM',mood:'memory'},
 {id:'B13',s:108,e:118,place:'FIELD',mood:'flash'},
 {id:'B14',s:118,e:120,place:'FIELD',mood:'white'}
];
const canvas=document.getElementById('stage'), status=document.getElementById('status');
const renderer=new THREE.WebGLRenderer({canvas,alpha:false,antialias:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(1);renderer.setSize(W,H,false);renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.NoToneMapping;renderer.setClearColor(0x15233e);
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(2*Math.atan(9/20)*180/Math.PI,16/9,.1,100);
camera.position.set(0,0,10);camera.lookAt(0,0,0);
const cameraTimeline=gsap.timeline({paused:true});
let camX=0;
for(const b of beats){
  const duration=b.e-b.s;
  cameraTimeline.set(camera.position,{x:camX,y:0,z:10},b.s);
  const signed=(Number(b.id.slice(1))%2 ? 1:-1);
  camX=signed*(b.place==='MAP'?.3:.16);
  cameraTimeline.to(camera.position,{x:camX,y:b.mood==='white'?.08:-.035,z:b.place==='PHONE'?9.55:b.place==='MAP'?10.3:9.8,duration,ease:'power1.inOut'},b.s);
}
const rig=new window.Hunyuan2D({id:'Hunyuan',x:1180,y:820,scale:.78,view:'quarterRight'});
// The same user-supplied editable native 2D rig performs across every scene.
rig.add('body','sleep',{},0,.05);
rig.add('emotion','emotion',{emotion:'neutral'},0,0);
rig.add('body','stand',{},14.25,1.1);
rig.add('view','view',{view:'quarterRight'},14.3,.3);
rig.add('emotion','emotion',{emotion:'surprised'},15,0);
// Step away from the mattress to the open floor: preserve native gait and foot root.
rig.add('body','walk',{to:{x:1470,y:940}},16.7,6.2);
rig.add('view','view',{view:'sideRight'},16.7,0);
rig.add('emotion','emotion',{emotion:'confused'},23,0);
rig.add('gesture','point',{direction:1},27.5,1.3);
rig.add('emotion','emotion',{emotion:'afraid'},33,0);
rig.add('view','view',{view:'front'},40.5,.3);
rig.add('head','shake',{},41.8,1.2);
rig.add('head','shake',{},44,1.2);
rig.add('head','shake',{},46.4,1.1);
rig.add('emotion','emotion',{emotion:'confused'},48,0);
rig.add('emotion','emotion',{emotion:'afraid'},59,0);
rig.add('gesture','point',{direction:1},70.5,1.2);
rig.add('view','view',{view:'sideRight'},72,.5);
for(let start=75;start<118;start+=7){
  const p=rig.poseAt(start);
  const toX=(p.x<1200)?(p.x+170):(p.x-170);
  rig.add('body','run',{to:{x:toX,y:940}},start,6.65);
  rig.add('view','view',{view:'sideRight'},start,0);
}
rig.add('emotion','emotion',{emotion:'surprised'},116.3,0);
rig.add('body','idle',{to:{x:rig.poseAt(118).x,y:820}},118,0);

const actorCanvas=document.createElement('canvas');actorCanvas.width=W;actorCanvas.height=H;
const actorCtx=actorCanvas.getContext('2d',{alpha:true});
const actorTexture=new THREE.CanvasTexture(actorCanvas);actorTexture.colorSpace=THREE.SRGBColorSpace;
const graphicCanvas=document.createElement('canvas');graphicCanvas.width=W;graphicCanvas.height=H;
const g=graphicCanvas.getContext('2d',{alpha:true});
const graphicTexture=new THREE.CanvasTexture(graphicCanvas);graphicTexture.colorSpace=THREE.SRGBColorSpace;
function plane(tex,z,width,order){const mat=new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false,side:THREE.DoubleSide,toneMapped:false});const mesh=new THREE.Mesh(new THREE.PlaneGeometry(width,width*H/W),mat);mesh.position.z=z;mesh.renderOrder=order;scene.add(mesh);return mesh;}
const background=[];
for(const [i,z,width] of [[0,-2.0,21],[1,-.65,19.6],[2,1.4,17.7]]){
  const c=document.createElement('canvas');c.width=W;c.height=H;
  const ctx=c.getContext('2d',{alpha:true});const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
  background.push({c,ctx,tex,mesh:plane(tex,z,width,i)});
}
plane(actorTexture,.2,16.4,3);plane(graphicTexture,2.4,12.7,5);
const baseAsset={};
for(const key of ['distant','mid','foreground']){
 const img=new Image();img.src='assets/'+key+'.svg';await img.decode();baseAsset[key]=img;
}
function svgToImage(svg){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));const im=new Image();im.onload=()=>{URL.revokeObjectURL(url);resolve(im)};im.onerror=()=>{URL.revokeObjectURL(url);reject(Error('Original vector rasterization failed'))};im.src=url;});}
function svg(layer,body){return `<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><defs>
<linearGradient id="sky" x2=".9" y2="1"><stop stop-color="#101d51"/><stop offset=".48" stop-color="#40668a"/><stop offset="1" stop-color="#f8ac86"/></linearGradient>
<linearGradient id="ground" x2="0" y2="1"><stop stop-color="#4c677c"/><stop offset="1" stop-color="#152d48"/></linearGradient>
<linearGradient id="green" x2="0" y2="1"><stop stop-color="#a4d4ad"/><stop offset="1" stop-color="#376b69"/></linearGradient>
<radialGradient id="glow"><stop stop-color="#fff4c9" stop-opacity=".98"/><stop offset="1" stop-color="#f0a475" stop-opacity="0"/></radialGradient>
<pattern id="grain" width="68" height="54" patternUnits="userSpaceOnUse"><circle cx="13" cy="11" r="1.4" fill="#c2d5ce" opacity=".32"/><circle cx="44" cy="39" r="1.5" fill="#fed9ae" opacity=".22"/></pattern>
</defs>${body}</svg>`;}
function lines(seed,count=28){let out='';for(let i=0;i<count;i++){const x=(i*157+seed*89)%1920,y=(i*97+seed*71)%1080;out+=`<circle cx="${x}" cy="${y}" r="${i%3+1}" fill="#ffe5c4" opacity=".34"/>`;}return out;}
function streetLayer(part){
 if(part===0)return svg(part,`<rect width="1920" height="1080" fill="url(#sky)"/><path d="M0 550Q380 390 810 560T1920 470V1080H0Z" fill="#385979"/><circle cx="1550" cy="252" r="260" fill="url(#glow)"/>${lines(8)}<g fill="#273e61"><path d="M0 235h200v450H0Z M225 365h170v320H225Z M435 155h275v540H435Z M754 315h230v380H754Z M1040 180h290v515h-290Z M1380 305h200v390h-200Z M1620 135h300v565h-300Z"/></g>`);
 if(part===1)return svg(part,`<path d="M0 670H1920V1080H0Z" fill="#3b5265"/><path d="M0 690L950 625L1920 690V1080H0Z" fill="#39445c"/><path d="M930 640L1050 640L1500 1080H380Z" fill="#e9b98c" opacity=".56"/><path d="M985 640L1015 640L1120 1080H840Z" fill="#ffd2a8"/><path d="M960 650v430" stroke="#f4d19c" stroke-width="18" stroke-dasharray="55 65"/><g stroke="#1a2e4b" stroke-width="14"><path d="M95 680V390M337 680V410M1650 700V440"/></g><g fill="#f4d29f"><rect x="65" y="371" width="56" height="22" rx="8"/><rect x="307" y="390" width="56" height="22" rx="8"/><rect x="1617" y="417" width="64" height="24" rx="8"/></g><g transform="translate(300 750)"><path d="M-150 0h340l73 65v95h-460v-97Z" fill="#f28f86" stroke="#212f54" stroke-width="17"/><path d="M-90 -62h185l78 68h-355Z" fill="#91bed0" stroke="#283954" stroke-width="18"/><circle cx="-120" cy="150" r="39" fill="#1b233b" stroke="#ffcda7" stroke-width="12"/><circle cx="150" cy="150" r="39" fill="#1b233b" stroke="#ffcda7" stroke-width="12"/></g><g transform="translate(1460 690) scale(.85)"><path d="M-175 25h350l68 65v76h-460V82Z" fill="#87c7c0" stroke="#243e58" stroke-width="18"/><path d="M-95 -50h195l67 75h-325Z" fill="#d2edda" stroke="#29465f" stroke-width="17"/><circle cx="-112" cy="162" r="40" fill="#1b233b" stroke="#ffcda7" stroke-width="12"/><circle cx="143" cy="162" r="40" fill="#1b233b" stroke="#ffcda7" stroke-width="12"/></g>`);
 return svg(part,`<g fill="#293950" stroke="#15263d" stroke-width="9"><path d="M0 925l350 48 65 107H0Z M1920 920l-370 40-86 120h456Z"/><path d="M120 946v134m166-122v122m131-85v85m1073-120v120m195-135v135"/></g><g fill="#8cbfb4" stroke="#294966" stroke-width="13"><path d="M0 780q90-120 180-5l-25 85H0Z M1770 755q85-113 150-17v177h-150Z"/></g>`);
}
function farmLayer(part,field=false){
 if(part===0)return svg(part,`<rect width="1920" height="1080" fill="url(#sky)"/><circle cx="1485" cy="275" r="300" fill="url(#glow)"/><path d="M0 560Q380 270 780 540T1920 380v700H0Z" fill="#46677b"/><path d="M0 628Q490 408 960 574T1920 506v574H0Z" fill="#699590"/><path d="M0 700Q500 575 990 665T1920 585v495H0Z" fill="#7caa8d"/>${lines(7)}`);
 if(part===1)return svg(part,`<path d="M0 715Q500 570 980 730T1920 690v390H0Z" fill="url(#green)"/><path d="M570 940Q760 712 910 688T1370 1080H920Z" fill="#c59b77" opacity=".8"/><path d="M1210 610h435v320h-435Z" fill="#f4c895" stroke="#694d68" stroke-width="21"/><path d="M1152 622l275-235 296 235Z" fill="#924d63" stroke="#482f55" stroke-width="23"/><rect x="1335" y="730" width="160" height="200" fill="#3b526c" stroke="#fff0ce" stroke-width="17"/><rect x="1530" y="675" width="78" height="103" fill="#81bac8" stroke="#f7ddba" stroke-width="17"/><path d="M1175 820l-120 98m-180-138 95 110" fill="none" stroke="#4c7566" stroke-width="33"/><circle cx="915" cy="840" r="100" fill="#423b49" stroke="#e1bb8e" stroke-width="17"/><circle cx="915" cy="840" r="74" fill="#6c7374" stroke="#333946" stroke-width="19"/><path d="M860 840h112M915 790v101" stroke="#354652" stroke-width="14"/>`);
 return svg(part,`<g fill="#284d4b" stroke="#356d62" stroke-width="17"><path d="M0 950Q230 780 380 1045v60H0Z M1640 970q120-230 280-140v250h-280Z"/></g><g stroke="#f5d29a" stroke-width="12" fill="none"><path d="M48 1080q70-120 140-10m155-5q95-136 180 0m1000 0q145-146 285 0"/></g><path d="M0 1070Q800 1020 1920 1065" fill="none" stroke="#b7cb9c" stroke-width="27"/>`);
}
function fieldLayer(part){
 if(part===0)return svg(part,`<rect width="1920" height="1080" fill="url(#sky)"/><ellipse cx="1640" cy="530" rx="440" ry="300" fill="url(#glow)"/><path d="M0 595Q480 420 980 565T1920 510v570H0Z" fill="#5b8791"/><path d="M0 670Q480 540 980 690T1920 570v510H0Z" fill="#77a58f"/>`);
 if(part===1)return svg(part,`<path d="M0 695Q480 603 920 730T1920 660v420H0Z" fill="#86b095"/><path d="M0 1000Q800 780 1920 960v120H0Z" fill="#cfba90"/><path d="M460 1080L1115 780 1410 780 1700 1080Z" fill="#c8a27e"/><g fill="#425a5c" stroke="#acc9ab" stroke-width="11"><circle cx="270" cy="840" r="60"/><circle cx="1480" cy="790" r="70"/><circle cx="1800" cy="850" r="55"/></g>`);
 return svg(part,`<g stroke="#244f49" stroke-width="11" fill="none"><path d="M60 1080Q100 950 120 845m50 240q40-150 125-190m180 180q20-160 45-230m1110 250q-60-180-90-260m210 245q-35-144-76-180m200 180q-30-165-95-205"/></g><g fill="#fff0b5"><circle cx="340" cy="1050" r="5"/><circle cx="840" cy="997" r="5"/><circle cx="1320" cy="1050" r="6"/></g>`);
}
function mapLayer(part){
 if(part===0)return svg(part,`<rect width="1920" height="1080" fill="#173755"/><path d="M0 250Q650 30 1920 250M0 620Q950 300 1920 610M0 990Q850 750 1920 930" stroke="#5d928e" stroke-width="35" opacity=".5" fill="none"/><circle cx="1410" cy="380" r="300" fill="url(#glow)"/>`);
 if(part===1)return svg(part,`<g stroke="#87bda3" stroke-width="9" opacity=".5" fill="none"><path d="M100 150q750 350 1700-60M150 550q820 240 1600-40M150 900q750-220 1650 30M400 0q240 550 90 1080M1100 0q-160 510 40 1080M1640 0q-130 660 70 1080"/></g><path d="M250 850Q530 520 800 615T1550 280" stroke="#ffe3a4" stroke-width="29" stroke-dasharray="32 23" fill="none"/><circle cx="250" cy="850" r="57" fill="#f28b83" stroke="#ffe4ac" stroke-width="14"/><circle cx="1550" cy="280" r="59" fill="#9ce0bf" stroke="#fff6c9" stroke-width="14"/><path d="M1395 380l155-125 155 125v175h-310Z" fill="#f3bd9a" stroke="#213d56" stroke-width="19"/><path d="M1360 380l190-158 195 158" stroke="#ef9088" stroke-width="40" fill="none"/>`);
 return svg(part,`<path d="M0 1050Q900 960 1920 1070" stroke="#a6d8bb" stroke-width="17" fill="none"/><g stroke="#f1dbac" stroke-width="10" opacity=".7"><path d="M80 140h250M80 168h180M1580 870h240M1640 903h180"/></g>`);
}
function phoneLayer(part){
 if(part===0)return svg(part,`<rect width="1920" height="1080" fill="#281e3c"/><ellipse cx="970" cy="440" rx="790" ry="570" fill="#69405c"/><ellipse cx="970" cy="490" rx="640" ry="550" fill="url(#glow)" opacity=".32"/>`);
 if(part===1)return svg(part,`<g transform="rotate(-6 960 540)"><rect x="570" y="20" width="780" height="1070" rx="95" fill="#1c253d" stroke="#a8c6c9" stroke-width="32"/><rect x="612" y="125" width="698" height="850" rx="22" fill="#d44650"/><rect x="790" y="65" width="340" height="28" rx="14" fill="#526173"/><path d="M640 310H1270" stroke="#f09f8a" stroke-width="6"/></g>`);
 return svg(part,`<path d="M0 1040Q340 935 580 1075M1350 1080q320-160 570-70" fill="none" stroke="#543955" stroke-width="85" opacity=".75"/>`);
}
function extraOverlay(id,part){
 if(id===4)return phoneLayer(part);
 if(id===10)return mapLayer(part);
 if(id===9)return streetLayer(part);
 if(id===11)return farmLayer(part);
 if(id>=12)return fieldLayer(part);
 if(part===0)return null;
 return null;
}
let sceneIndex=-1;
async function setBeat(i){
 const key=['distant','mid','foreground'];
 const images=await Promise.all(key.map(async(k,part)=>{const src=extraOverlay(i,part);return src?await svgToImage(src):baseAsset[k];}));
 for(let part=0;part<3;part++){
  const {c,ctx,tex}=background[part];ctx.clearRect(0,0,W,H);
  ctx.drawImage(images[part],0,0,W,H);
  tex.needsUpdate=true;
 }
 sceneIndex=i;
}
function roundRect(x,y,w,h,r,fill,stroke,sw=2){g.beginPath();g.roundRect(x,y,w,h,r);if(fill){g.fillStyle=fill;g.fill();}if(stroke){g.strokeStyle=stroke;g.lineWidth=sw;g.stroke();}}
function text(value,x,y,size=50,color='#fff6df',weight='700',align='left'){g.font=`${weight} ${size}px system-ui, sans-serif`;g.fillStyle=color;g.textAlign=align;g.fillText(value,x,y);g.textAlign='left';}
function label(str,x,y,color='#9fd9ce'){g.save();g.globalAlpha=.85;roundRect(x,y,Math.max(220,str.length*16+45),58,15,'#142e45cc','#9acacb',2);text(str,x+21,y+39,27,color,'650');g.restore();}
function circle(x,y,r,color){g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.fillStyle=color;g.fill();}
function graphicFrame(i,t){
 g.clearRect(0,0,W,H);
 const b=beats[i],u=t-b.s,d=b.e-b.s,k=Math.min(1,Math.max(0,u/.6)),out=Math.min(1,Math.max(0,(d-u)/.5));
 g.save();g.globalAlpha=k*out;
 const sway=Math.sin(t*3)*8;
 if(i===0){label('TUESDAY • 06:41',74,70);text('A perfectly ordinary morning',84,980,43,'#ffe6c9','600');}
 if(i===1){
  roundRect(1180,155,615,575,30,'#142a46ec','#f4d4aa',9);label('TODAY',1230,194);
  text('09:00',1250,340,112,'#f5bd8b','800');text('WORK MEETING',1250,405,42,'#dcf4ed');
  roundRect(1230,472,480,110,18,'#b8dbd5','#31516a',7);text('☕  HALF FINISHED',1260,543,39,'#243b52');
 }
 if(i===2){
  for(let r=0;r<3;r++){g.strokeStyle=`rgba(255,206,152,${.6-r*.17})`;g.lineWidth=12-r*2;g.beginPath();const radius=150+r*95+(u*82)%90;g.ellipse(1320,430,radius,radius*.65,0,0,Math.PI*2);g.stroke();}
  label('UNIDENTIFIED SIREN',80,94,'#ffb9ac');
  for(let j=0;j<24;j++){const h=30+Math.sin(j*.9+t*7)*60;roundRect(130+j*31,870-h,14,h*2,7,j%3?'#f3bc96':'#95d5cd');}
 }
 if(i===3){
  const x=1670+sway;
  // Keep Hunyuan's reaction and hands visible beside the alert, not behind it.
  g.save();g.translate(x,590);g.scale(.70,.70);g.rotate(Math.sin(t*39)*.035);
  roundRect(-175,-295,350,590,48,'#182a40','#d9e6df',16);
  roundRect(-146,-241,292,475,22,'#af324c');text('ALERT',-108,-100,45,'#ffe9d5');
  text('EMERGENCY',-110,-20,37,'#fff9e8');text('INBOUND',-110,44,50,'#fff9e8');g.restore();
  label('THIS IS NOT A DRILL',70,88,'#ffb0a0');
 }
 if(i===4){
  g.save();g.translate(0,24);text('EMERGENCY ALERT',961,394,70,'#fff2dc','850','center');
  roundRect(702,450,535,12,6,'#f6c6a7');
  text('MISSILE THREAT INBOUND',961,567,49,'#fff7dc','800','center');
  text('SEEK SHELTER IMMEDIATELY',961,650,47,'#fff7dc','800','center');g.restore();
  circle(950,802,14+Math.sin(t*7)*7,'#fff6c4');
 }
 if(i===5){
  label('SHOCK RESPONSE',74,82,'#ffc0ad');
  for(let j=0;j<3;j++){const x=260+j*280;roundRect(x,810,230,105,22,'#f3d8b9dd','#405870',6);text(`READ ${j+1}`,x+24,884,42,'#293e58');}
 }
 if(i===6){
  roundRect(112,192,690,370,35,'#1a3a57e8','#e8bb98',9);text('NORMALCY BIAS',175,315,63,'#ffe1a9','850');
  text('“Everything is fine.”',175,405,49,'#e5efe5','600');
  text('The dangerous first reaction',175,485,38,'#a6d8d0');
  for(let j=0;j<3;j++){g.strokeStyle='#efbb92';g.lineWidth=15-j*3;g.beginPath();g.arc(1515,420,110+j*58,(t*.7+j)*Math.PI,((t*.7+j)+1.3)*Math.PI);g.stroke();}
 }
 if(i===7){
  label('TIME REMAINING',100,80,'#ffd9bf');
  const left=Math.max(0,15*60-u),mins=Math.floor(left/60),secs=Math.floor(left%60);
  roundRect(115,600,665,235,36,'#831f37dd','#ffd7c1',11);text(`${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`,168,768,148,'#fff0df','850');
  g.strokeStyle='#f0b5a5';g.lineWidth=22;g.beginPath();g.arc(1450,450,260,-Math.PI/2,-Math.PI/2+2*Math.PI*(1-u/d));g.stroke();
 }
 if(i===8){
  label('MOVE. NOW.',88,89,'#ffb29b');
  const grab=Math.min(1,Math.max(0,(u-2)/3));const capX=1495+(rig.poseAt(t).x-1495)*grab;const capY=370+75*grab;
  g.save();g.translate(capX,capY);g.scale(1-.42*grab,1-.42*grab);g.rotate(Math.sin(t*4)*.08*(1-grab));g.fillStyle='#e7944d';g.strokeStyle='#442d3c';g.lineWidth=15;
  g.beginPath();g.ellipse(0,0,170,88,0,Math.PI,2*Math.PI);g.lineTo(160,24);g.quadraticCurveTo(55,160,-170,20);g.closePath();g.fill();g.stroke();g.restore();
  text('THE ORANGE CAP',1100,585,44,'#ffe4b7');
 }
 if(i===9){
  label('OUTSIDE • EVERY SECOND COUNTS',75,85,'#ffceaf');
  for(let j=0;j<12;j++){const x=160+j*136+Math.sin(t*3+j)*12,y=140+(j%3)*16;
   g.strokeStyle=j%2?'#f2b1a1':'#a7d6cd';g.lineWidth=8;g.beginPath();g.moveTo(x,y);g.lineTo(x+70,y+30);g.stroke();}
  roundRect(1290,210,540,125,25,'#a93245d9','#ffe1c2',8);text('DON’T STOP TO FILM',1322,287,35,'#fff4da');
 }
 if(i===10){label('A WAY OUT',78,86,'#fbe0bd');label('YOUR UNCLE’S SHELTER',1340,640,'#f9d4ad');
  g.strokeStyle='#ffdcab';g.lineWidth=18;g.setLineDash([28,26]);g.beginPath();g.moveTo(252,850);g.quadraticCurveTo(720,510,1000,615);g.quadraticCurveTo(1290,560,1550,280);g.stroke();g.setLineDash([]);
  text('CITY',180,960,46,'#fff4dc');text('FARMHOUSE',1390,746,47,'#fff4dc');
 }
 if(i===11){
  roundRect(145,163,830,180,31,'#f9d4aadc','#385168',7);text('“IT’S NOT PARANOIA.',200,235,55,'#34465c','800');text('IT’S INSURANCE.”',200,304,55,'#34465c','800');
  label('KEEP RUNNING',1150,82,'#ffe0bb');
 }
 if(i===12){
  label('THE SKY CHANGES',95,75,'#ffe0bc');
  const v=Math.min(1,Math.max(0,(t-114.5)/3));
  g.fillStyle=`rgba(255,250,225,${v*.6})`;g.fillRect(0,0,W,H);
  g.fillStyle=`rgba(255,255,255,${v*.85})`;g.fillRect(1380,0,540,H);
  g.fillStyle=`rgba(19,37,58,${v*.73})`;g.beginPath();g.moveTo(1130,920);g.lineTo(-100,1030);g.lineTo(0,1080);g.lineTo(1370,960);g.closePath();g.fill();
 }
 if(i===13){
  const v=Math.max(0,Math.min(1,u/.65));
  g.fillStyle=`rgba(255,255,250,${.68+v*.32})`;g.fillRect(0,0,W,H);
  g.save();g.globalAlpha=.7*(1-v*.6);text('WHITE.',110,865,122,'#344f69','900');g.restore();
 }
 // Minimal edge ornament; no constant subtitles or distracting cards.
 g.restore();
}
let ready=false, serial=0;
async function renderFrame(t){
 if(!Number.isFinite(t)||t<0||t>=DURATION)throw Error('Frame outside first 120 seconds');
 const me=++serial;
 const i=beats.findIndex((b,j)=>t>=b.s&&(t<b.e||j===beats.length-1));
 if(i<0)throw Error('Story beat missing at '+t);
 if(sceneIndex!==i)await setBeat(i);
 if(serial!==me)throw Error('Stale seek during scene load');
 cameraTimeline.seek(t,false);camera.lookAt(0,0,0);
 const p=rig.poseAt(t);
 // SVG art remains sourced from the exact native supplied Hunyuan engine.
 actorCtx.clearRect(0,0,W,H);
 if(![4,10].includes(i)){
  const im=await svgToImage(window.HunyuanArt.svg(rig.svgAt(t),W,H));
  if(serial!==me)throw Error('Stale Hunyuan character rasterization');
  // Static set-blocking offsets after exterior hard cuts; native rig alone does root travel.
  // Keep running feet on the roadway/field, never on cars or farmhouse walls.
  const setOffset=i===9?-380:i===11?-300:i>=12?-230:0;
  actorCtx.save();actorCtx.translate(setOffset,0);actorCtx.drawImage(im,0,0,W,H);actorCtx.restore();
 }
 actorTexture.needsUpdate=true;
 graphicFrame(i,t);graphicTexture.needsUpdate=true;
 renderer.render(scene,camera);
 return {t,beat:beats[i].id,rigAction:p.action};
}
await renderFrame(0);ready=true;window.ready=true;window.renderFrame=renderFrame;
status.textContent='Native Hunyuan 2D • 120-second cinematic production';
window.exportShard=async function(start,end){
 if(!ready||!Number.isInteger(start)||!Number.isInteger(end)||start<0||end>120||start>=end||start%10||end-start!==10)throw Error('Invalid fixed ten-second render shard');
 const source=new CanvasSource(canvas,{codec:'avc',quality:new Quality({bitrate:8e6})});
 const output=new Output({format:new Mp4OutputFormat(),target:new BufferTarget()});
 output.addVideoTrack(source,{frameRate:FPS});await output.start();
 for(let f=0;f<(end-start)*FPS;f++){
  await renderFrame(start+f/FPS);
  await source.add(f/FPS,1/FPS);
 }
 await output.finalize();const buf=output.target.buffer;
 if(!buf||buf.byteLength<30000)throw Error('Mediabunny shard is incomplete');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([buf],{type:'video/mp4'}));
 a.download=`shard_${String(start/10).padStart(2,'0')}.mp4`;document.body.appendChild(a);a.click();a.remove();
 return {bytes:buf.byteLength,start,end,frames:(end-start)*FPS};
};
// WebAudio OfflineAudioContext: all-original procedural, intentionally quiet SFX.
// It is separately exported and mixed under the established KIE narration in FFmpeg.
window.exportSfx=async function(){
 const rate=24000,offline=new OfflineAudioContext(1,DURATION*rate,rate),master=offline.createGain();
 master.gain.value=.12;master.connect(offline.destination);
 function tone(at,len,from,to,amp=.12,wave='sine'){
  const osc=offline.createOscillator(),vol=offline.createGain();osc.type=wave;osc.frequency.setValueAtTime(from,at);osc.frequency.exponentialRampToValueAtTime(Math.max(to,1),at+len);
  vol.gain.setValueAtTime(.0001,at);vol.gain.linearRampToValueAtTime(amp,at+.12);vol.gain.exponentialRampToValueAtTime(.0001,at+len);
  osc.connect(vol);vol.connect(master);osc.start(at);osc.stop(at+len);
 }
 tone(13.6,8.1,190,420,.2,'sawtooth');tone(23,5,75,140,.07);
 tone(33.1,1,430,260,.18,'square');tone(34.1,1,430,260,.18,'square');
 tone(40.7,3.0,85,52,.06);tone(59.2,10,120,61,.09);
 for(let i=0;i<14;i++)tone(73+i*3.15,.21,120,55,.03,'triangle');
 tone(114.5,5,82,580,.2,'sawtooth');
 const pcm=(await offline.startRendering()).getChannelData(0);
 const array=new ArrayBuffer(44+pcm.length*2),dv=new DataView(array),out=new Uint8Array(array);
 function str(pos,s){for(let i=0;i<s.length;i++)out[pos+i]=s.charCodeAt(i)}
 str(0,'RIFF');dv.setUint32(4,36+pcm.length*2,true);str(8,'WAVE');str(12,'fmt ');
 dv.setUint32(16,16,true);dv.setUint16(20,1,true);dv.setUint16(22,1,true);dv.setUint32(24,rate,true);
 dv.setUint32(28,rate*2,true);dv.setUint16(32,2,true);dv.setUint16(34,16,true);str(36,'data');dv.setUint32(40,pcm.length*2,true);
 for(let i=0;i<pcm.length;i++)dv.setInt16(44+i*2,Math.max(-32768,Math.min(32767,Math.round(pcm[i]*32767))),true);
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([array],{type:'audio/wav'}));a.download='original_sfx_120s.wav';document.body.appendChild(a);a.click();a.remove();
 return {seconds:DURATION,bytes:array.byteLength};
};
let raf=null,epoch=0;
document.getElementById('play').onclick=()=>{if(raf!==null)return;epoch=performance.now();const tick=async(now)=>{if(raf===null)return;const t=((now-epoch)/1000)%DURATION;try{await renderFrame(t)}catch(e){status.textContent=e.message;raf=null;return;}raf=requestAnimationFrame(tick);};raf=requestAnimationFrame(tick);};
document.getElementById('pause').onclick=()=>{if(raf!==null)cancelAnimationFrame(raf);raf=null;};
