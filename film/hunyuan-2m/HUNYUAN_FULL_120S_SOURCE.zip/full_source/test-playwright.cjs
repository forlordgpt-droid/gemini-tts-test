const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=__dirname,PORT=8473, SHARD=Number(process.env.SHARD_INDEX), SFX=process.env.EXPORT_SFX==='1';
if(!SFX&&(!Number.isInteger(SHARD)||SHARD<0||SHARD>=12))throw Error('SHARD_INDEX must be 0-11');
const MIME={'.html':'text/html','.js':'application/javascript','.svg':'image/svg+xml','.m4a':'audio/mp4','.json':'application/json'};
const server=http.createServer((req,res)=>{try{const u=new URL(req.url,`http://127.0.0.1:${PORT}`),p=u.pathname==='/'?'/index.html':u.pathname;const full=path.resolve(ROOT,'.'+decodeURI(p));if(!full.startsWith(ROOT+path.sep))throw Error('Path escape');const data=fs.readFileSync(full);res.writeHead(200,{'content-type':MIME[path.extname(full)]||'application/octet-stream','cache-control':'no-store'});res.end(data)}catch(e){res.writeHead(404);res.end('not found')}});
(async()=>{await new Promise(r=>server.listen(PORT,'127.0.0.1',r));const browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-unsafe-swiftshader']});const page=await browser.newPage({viewport:{width:1920,height:1080},acceptDownloads:true});const failures=[];
page.on('pageerror',e=>failures.push(String(e)));page.on('console',m=>{if(m.type()==='error')failures.push(m.text())});
try{
 await page.goto(`http://127.0.0.1:${PORT}/`);await page.waitForFunction(()=>window.ready===true,{timeout:30000});
 fs.mkdirSync(path.join(ROOT,'qc'),{recursive:true});
 if(SFX){const downloadPromise=page.waitForEvent('download',{timeout:120000});const details=await page.evaluate(()=>window.exportSfx());const file=await downloadPromise;await file.saveAs(path.join(ROOT,'qc','original_sfx_120s.wav'));console.log('SFX duration',JSON.stringify(details));}
 else {
  const start=SHARD*10,end=start+10,canvas=page.locator('#stage');
  for(const t of [start+.15,start+5,start+9.5]){
   const check=await page.evaluate(x=>window.renderFrame(x),t);
   const name=`shard_${String(SHARD).padStart(2,'0')}_at_${String(t).replace('.','_')}.png`;
   await canvas.screenshot({path:path.join(ROOT,'qc',name)});
   if(check.beat!==['B01','B02','B03','B04','B05','B06','B07','B08','B09','B10','B11','B12','B13','B14'].find((id,i)=>t<([6,14,23,33,41,48,59,70,78,88,99,108,118,120][i])))throw Error('Unexpected story beat at '+t);
  }
  await page.evaluate(t=>window.renderFrame(t),start+.2);const a=await canvas.screenshot();
  await page.evaluate(t=>window.renderFrame(t),start+7.2);
  await page.evaluate(t=>window.renderFrame(t),start+.2);const b=await canvas.screenshot();
  if(!a.equals(b))throw Error('Backwards timeline seek changed a deterministic frame');
  const pixels=await page.evaluate(()=>{const c=document.getElementById('stage'),ctx=document.createElement('canvas').getContext('2d');ctx.canvas.width=1920;ctx.canvas.height=1080;ctx.drawImage(c,0,0);return [[120,210],[1510,330],[420,620]].map(([x,y])=>Array.from(ctx.getImageData(x,y,1,1).data).slice(0,3));});
  if(pixels.every(rgb=>rgb[0]===21&&rgb[1]===35&&rgb[2]===62))throw Error('Only a flat WebGL clear-color rendered');
  const pending=page.waitForEvent('download',{timeout:360000});
  const info=await page.evaluate(({s,e})=>window.exportShard(s,e),{s:start,e:end});const download=await pending;
  await download.saveAs(path.join(ROOT,'qc',`shard_${String(SHARD).padStart(2,'0')}.mp4`));
  if(info.frames!==300)throw Error('Shard frame count wrong: '+JSON.stringify(info));
  console.log('PASS native Hunyuan illustrated film shard',JSON.stringify(info));
 }
 if(failures.length)throw Error('Browser errors: '+failures.join('; '));
}finally{await browser.close();await new Promise(r=>server.close(r))}})().catch(e=>{console.error(e.stack);process.exitCode=1});
