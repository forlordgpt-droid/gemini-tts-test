import * as THREE from 'three';
import gsap from 'gsap';
import { Output, Mp4OutputFormat, BufferTarget, CanvasSource, Quality } from 'mediabunny';
const W=1920,H=1080,FPS=30,DURATION=8;
const canvas=document.getElementById('stage');
const status=document.getElementById('status');
const renderer=new THREE.WebGLRenderer({canvas,alpha:false,antialias:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(1);renderer.setSize(W,H,false);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.NoToneMapping;
renderer.setClearColor(0x1d2c52);
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(2*Math.atan(9/20)*180/Math.PI,16/9,.1,100);
camera.position.set(-.22,0,10);
camera.lookAt(0,0,0);
const cameraTimeline=gsap.timeline({paused:true});
cameraTimeline.to(camera.position,{x:.16,z:9.75,duration:8,ease:'power1.inOut'},0);
const rig=new window.Hunyuan2D({id:'Hunyuan',x:1180,y:760,scale:.78,view:'quarterRight'});
// The native engine is not replaced by a static picture. Its pose is sampled absolutely.
rig.add('body','sleep',{},0,.02);
rig.add('body','stand',{},5.45,1);
rig.add('emotion','emotion',{emotion:'surprised'},6.6,0);
rig.add('view','view',{view:'front'},6.5,.35);
const actorCanvas=document.createElement('canvas'); actorCanvas.width=W; actorCanvas.height=H;
const actorCtx=actorCanvas.getContext('2d',{alpha:true});
const actorTexture=new THREE.CanvasTexture(actorCanvas);actorTexture.colorSpace=THREE.SRGBColorSpace;
function plane(texture,z,width,order,transparent=true){
 const mat=new THREE.MeshBasicMaterial({map:texture,transparent,depthWrite:false,side:THREE.DoubleSide,toneMapped:false});
 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(width,width*H/W),mat);mesh.position.z=z;mesh.renderOrder=order;scene.add(mesh);return mesh;
}
async function asset(url){
 const img=new Image();img.src=url;await img.decode();
 const tex=new THREE.Texture(img);tex.needsUpdate=true;tex.colorSpace=THREE.SRGBColorSpace;return tex;
}
await Promise.all([
 asset('assets/distant.svg').then(tex=>plane(tex,-2,21,0)),
 asset('assets/mid.svg').then(tex=>plane(tex,-.65,19.6,1)),
 asset('assets/foreground.svg').then(tex=>plane(tex,1.5,17,3))
]);
plane(actorTexture,.2,16.4,2);
let paintSerial=0;
function svgToImage(svg){return new Promise((resolve,reject)=>{const blob=new Blob([svg],{type:'image/svg+xml;charset=utf-8'});const url=URL.createObjectURL(blob);const im=new Image();im.onload=()=>{URL.revokeObjectURL(url);resolve(im)};im.onerror=e=>{URL.revokeObjectURL(url);reject(new Error('Original Hunyuan SVG decoding failed'))};im.src=url;});}
async function renderFrame(t){
 if(!Number.isFinite(t)||t<0||t>DURATION)throw Error('Frame time outside sample');
 const serial=++paintSerial;
 cameraTimeline.seek(t,false);camera.lookAt(0,0,0);
 const rigSvg=window.HunyuanArt.svg(rig.svgAt(t),W,H);
 const img=await svgToImage(rigSvg);
 if(serial!==paintSerial)throw Error('Stale actor rasterization');
 actorCtx.clearRect(0,0,W,H);actorCtx.drawImage(img,0,0);
 actorTexture.needsUpdate=true;
 renderer.render(scene,camera);
 return {t,rig:rig.poseAt(t).action,view:rig.poseAt(t).view};
}
let ready=false;await renderFrame(0);ready=true;status.textContent='Hunyuan native 2D preview ready · 8-second QC scene';
window.renderFrame=renderFrame;window.ready=true;
window.exportFilm=async function(){
 if(!ready)throw Error('Assets not ready');
 const source=new CanvasSource(canvas,{codec:'avc',quality:new Quality({bitrate:8e6})});
 const output=new Output({format:new Mp4OutputFormat(),target:new BufferTarget()});
 output.addVideoTrack(source,{frameRate:FPS});
 await output.start();
 for(let i=0;i<FPS*DURATION;i++){
  const t=i/FPS;
  await renderFrame(t);
  await source.add(t,1/FPS);
 }
 await output.finalize();
 const buffer=output.target.buffer;
 if(!buffer||buffer.byteLength<25000)throw Error('Mediabunny produced incomplete video');
 const url=URL.createObjectURL(new Blob([buffer],{type:'video/mp4'}));
 const a=document.createElement('a');a.href=url;a.download='hunyuan_8sec_video_only.mp4';document.body.appendChild(a);a.click();a.remove();
 return {bytes:buffer.byteLength,frames:FPS*DURATION};
};
let timer=null,t0=0;
document.getElementById('play').onclick=()=>{if(timer)return;t0=performance.now();timer=requestAnimationFrame(async function tick(now){if(!timer)return;const t=((now-t0)/1000)%DURATION;try{await renderFrame(t)}catch(e){status.textContent=e.message;timer=null;return}timer=requestAnimationFrame(tick)})};
document.getElementById('pause').onclick=()=>{if(timer)cancelAnimationFrame(timer);timer=null};
document.getElementById('record').onclick=async()=>{status.textContent='Exporting 240 frames...';try{const r=await window.exportFilm();status.textContent='Saved video-only MP4; audio is muxed by verified FFmpeg';}catch(e){status.textContent='Export error: '+e.message;throw e}};
