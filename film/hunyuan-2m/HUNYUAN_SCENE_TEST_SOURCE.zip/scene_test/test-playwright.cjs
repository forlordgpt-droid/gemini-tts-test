const { chromium }=require('playwright');
const http=require('http');const fs=require('fs');const path=require('path');
const ROOT=__dirname, PORT=8472;
const MIME={'.html':'text/html','.js':'application/javascript','.svg':'image/svg+xml','.m4a':'audio/mp4','.json':'application/json'};
const server=http.createServer((req,res)=>{try{const url=new URL(req.url,`http://127.0.0.1:${PORT}`);const route=url.pathname==='/'?'/index.html':url.pathname;const full=path.resolve(ROOT,'.'+decodeURI(route));if(!full.startsWith(ROOT+path.sep))throw Error('Path escape');const data=fs.readFileSync(full);res.writeHead(200,{'content-type':MIME[path.extname(full)]||'application/octet-stream','cache-control':'no-store'});res.end(data)}catch(e){res.writeHead(404);res.end('not found')}});
(async()=>{await new Promise(r=>server.listen(PORT,'127.0.0.1',r));const browser=await chromium.launch({channel:'chromium',headless:true,args:['--enable-unsafe-swiftshader']});const page=await browser.newPage({viewport:{width:1920,height:1080},acceptDownloads:true});const failures=[];page.on('pageerror',e=>failures.push(String(e)));page.on('console',m=>{if(m.type()==='error')failures.push(m.text())});try{
await page.goto(`http://127.0.0.1:${PORT}/`);await page.waitForFunction(()=>window.ready===true,{timeout:30000});
fs.mkdirSync(path.join(ROOT,'qc'),{recursive:true});
const canvas=page.locator('#stage');
for(const t of [0,1.5,4.5,6.9]){await page.evaluate(t=>window.renderFrame(t),t);await canvas.screenshot({path:path.join(ROOT,'qc',`frame_${String(t).replace('.','_')}.png`)})}
await page.evaluate(()=>window.renderFrame(1.5));const first=await canvas.screenshot();await page.evaluate(()=>window.renderFrame(6.9));await page.evaluate(()=>window.renderFrame(1.5));const again=await canvas.screenshot();if(!first.equals(again))throw Error('Deterministic backwards seek did not reproduce the same frame');
const pending=page.waitForEvent('download',{timeout:240000});await page.evaluate(()=>window.exportFilm());const download=await pending;await download.saveAs(path.join(ROOT,'qc','hunyuan_8sec_video_only.mp4'));
if(failures.length)throw Error('Browser errors: '+failures.join('; '));
console.log('PASS: original rig render, seeded absolute-time seek, three depth layers, Mediabunny H264 MP4 export, 240 frames');
}finally{await browser.close();await new Promise(r=>server.close(r))}})().catch(e=>{console.error(e.stack);process.exitCode=1});
