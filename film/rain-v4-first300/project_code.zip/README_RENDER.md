# Corrected first five minutes — production package

Source chronology: `What If It Never Stopped Raining for 10 Years.txt`, from 00:00 through 05:00. The 83-shot script deliberately corrects the sparse protagonist staging of the previous 120-second edition. Walt appears from 03:28, not before. Nia first appears at 10:11 and is outside this scope.

## Locked production method

- GHCR pinned Hunyuan Cinematic Engine V3 unchanged image digest: `sha256:4026e6a686120cbed05b650bbecda54c377fcd91fbb56b844e9f87fdc6ef4df7`.
- Active V4 still-actor profile supersedes historical animated Hunyuan rig. Three.js PerspectiveCamera, GSAP, WebCodecs, Mediabunny, Canvas2D and Web Audio OfflineAudioContext.
- Use 77 approved original illustration-derived static images; no SnapGen calls, paid image generation or identity substitutions.
- Main protagonist is planned as present for about 63% of 00:00–02:00 and 65% of 00:00–05:00. This is a planned shot-stage proportion; screenshots and creative review still required.
- Audio 00:00–02:00 is extracted from the already approved existing `RAIN_V4_FIRST120_COMPLETE.mp4`; no fresh TTS. New sections use 12 already successful exact Kie.ai `google/gemini-3-8-flash-tts` Fola WAVs, no retries and no retiming.
- Outputs: 1920×1080 30 fps 9,000 decoded frames, H.264 + AAC, 300 seconds.

## Reconstruct

1. Unzip `project_code.zip` into `film/rain-v4-first300/`.
2. `python3 film/rain-v4-first300/restore_assets.py` reassembles and verifies ten(s) of small asset-parts into 77 WebP layers.
3. Use pinned `/opt/cinematic/engine/scripts/render_shard.cjs` with `--project film/rain-v4-first300/scenes --start-frame 0 ... --frame-count 150` in 150-frame shards. All 60 are run by GitHub Actions with `max-parallel: 8`.
4. Render `RAIN_V4_120TO300_ORIGINAL_SFX.wav` from the authored `window.exportRainSfx` with the included `render_sfx_180.cjs`.
5. `assemble300.py` verifies hashes, 60 parts, original 120s audio and 12 new recordings, and exports canonical MP4/QA/contact sheet.

Source imagery and historical original movie remain unchanged; the final first-two-minute *visuals* are intentionally revised as requested, not byte-identical to the previous film. Human poses never morph or animate.
