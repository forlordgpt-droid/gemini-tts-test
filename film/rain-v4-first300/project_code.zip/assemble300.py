#!/usr/bin/env python3
"""Deterministic V4 9000-frame assembly. Reuse exact prior speech. No paid calls.
Inputs: 60 new 150-frame shards, previously approved first120 mixed audio,
12 source Kie Flash Fola WAV files, one Web Audio OfflineAudioContext original 180s atmosphere.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,math,io,wave
from PIL import Image,ImageOps,ImageDraw
BASE=Path.cwd();ROOT=BASE/'film/rain-v4-first300';OUT=BASE/'delivery';OUT.mkdir(exist_ok=True)
MAN=json.loads((ROOT/'film_manifest.json').read_text());PARTS=BASE/'parts';VOICES=BASE/'voices';OLD=BASE/'first120/RAIN_V4_FIRST120_COMPLETE.mp4'
RESULT=OUT/'RAIN_V4_CHARACTER_CORRECTED_FIRST300.mp4'

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(args,timeout=2400):
 print('PROCESS',args[0],len(args),'arguments',flush=True)
 subprocess.run(args,check=True,timeout=timeout)
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,codec_type,width,height,r_frame_rate,nb_frames,sample_rate:format=duration,size','-of','json',str(p)],text=True))
def verify():
 assert OLD.is_file() and sha(OLD)==MAN['approved_first120_sha256'],'Original audio source altered'
 original=probe(OLD);v=next(s for s in original['streams'] if s['codec_type']=='video')
 assert v['width']==1920 and v['height']==1080 and int(v['nb_frames'])==3600 and abs(float(original['format']['duration'])-120)<.15
 clips=[]
 for n in range(0,9000,150):
  d=PARTS/f'RAIN_V4_FIRST300_SHARD_{n}';p=d/f'part_{n}_150.mp4';report=d/'shard_qc.json'
  assert p.is_file() and report.is_file(),(n,p,report)
  q=json.loads(report.read_text());assert q['pass'] and q['start_frame']==n and q['frame_count']==150
  assert sha(p)==q['sha256'],n
  fmt=probe(p);s=next(y for y in fmt['streams'] if y['codec_type']=='video')
  assert (s['codec_name'],s['width'],s['height'],s['r_frame_rate'],int(s['nb_frames']))==('h264',1920,1080,'30/1',150),n
  assert abs(float(fmt['format']['duration'])-5)<.1,n
  clips.append(p)
 voices=[]
 for entry in MAN['speech']['new_120to300']:
  seg=entry['segment'];p=VOICES/f'RAIN_V4_FIRST300_FOLA_{seg}'/entry['filename'];assert p.is_file(),p
  assert sha(p)==entry['sha256'],seg
  with wave.open(str(p),'rb') as w:
   assert (w.getframerate(),w.getnchannels(),w.getsampwidth())==(24000,1,2)
   assert abs(w.getnframes()/24000-entry['duration'])<.0001
  voices.append(p)
 sfx=PARTS/'RAIN_V4_FIRST300_SHARD_3600/RAIN_V4_120TO300_ORIGINAL_SFX.wav';assert sfx.is_file()
 with wave.open(str(sfx),'rb') as w:
  assert (w.getframerate(),w.getnchannels(),w.getsampwidth(),w.getnframes())==(24000,1,2,180*24000), (w.getframerate(),w.getnframes())
 print(json.dumps({'stage':'SOURCE_VERIFICATION_PASSED','shards':len(clips),'frames':len(clips)*150,'approved_prior_audio':True,'voice_segments':len(voices),'web_audio_seconds':180,'new_paid_calls':0}),flush=True)
 return clips,voices,sfx

def picture(clips):
 list_file=OUT/'ordered_sources.txt'
 list_file.write_text(''.join("file '"+str(p.resolve())+"'\n" for p in clips))
 video=OUT/'CANONICAL_VIDEO_9000.mp4'
 # One decode -> one new visual encode. Recovered canonical timestamps are derived from frame number, not prior PTS.
 command=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(list_file),'-an',
  '-vf','settb=AVTB,setpts=N/(30*TB),fps=30,format=yuv420p',
  '-frames:v','9000','-r','30','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-bf','0','-threads','4','-movflags','+faststart',str(video)]
 run(command,timeout=4800)
 q=probe(video);v=q['streams'][0]
 assert (v['codec_name'],v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==('h264',1920,1080,'30/1',9000),q
 assert abs(float(q['format']['duration'])-300)<.11
 return video

def soundtrack(video,voices,sfx):
 sources=[video,OLD,*voices,sfx]
 command=['ffmpeg','-hide_banner','-loglevel','error','-y']
 for x in sources:command.extend(['-i',str(x)])
 filters=['[1:a]atrim=0:120,asetpts=PTS-STARTPTS,aresample=48000[old]'];labels=['[old]']
 for i,v in enumerate(MAN['speech']['new_120to300']):
  ms=round(v['start_second']*1000)
  filters.append(f'[{i+2}:a]aresample=48000,volume=1.0,adelay={ms}:all=1[n{i}]');labels.append(f'[n{i}]')
 # Last input is offscreen environment and independent-object audio, always after 120 seconds.
 idx=len(sources)-1
 filters.append(f'[{idx}:a]aresample=48000,volume=0.24,afade=t=in:st=0:d=0.45,afade=t=out:st=178.8:d=1.2,adelay=120000:all=1[amb]');labels.append('[amb]')
 filters.append(''.join(labels)+f'amix=inputs={len(labels)}:duration=longest:dropout_transition=0:normalize=0,alimiter=limit=0.94,atrim=0:300,asetpts=N/SR/TB[a]')
 command+=['-filter_complex',';'.join(filters),'-map','0:v:0','-map','[a]','-c:v','copy','-c:a','aac','-b:a','192k','-t','300','-movflags','+faststart',str(RESULT)]
 run(command,timeout=1200)

def qa():
 q=probe(RESULT);v=next(x for x in q['streams'] if x['codec_type']=='video');a=next(x for x in q['streams'] if x['codec_type']=='audio')
 assert (v['codec_name'],v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==('h264',1920,1080,'30/1',9000)
 assert a['codec_name']=='aac' and 299.90<float(q['format']['duration'])<300.10
 packets=subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','packet=dts_time','-of','csv=p=0',str(RESULT)],text=True)
 times=[float(x.strip()) for x in packets.splitlines() if x.strip() not in ('N/A','')]
 assert len(times)==9000 and all(b>a for a,b in zip(times,times[1:])),('nonmonotonic DTS',len(times))
 run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(RESULT),'-f','null','-'],timeout=1900)
 dec=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','json',str(RESULT)],text=True))
 assert int(dec['streams'][0]['nb_read_frames'])==9000
 shot=json.loads((ROOT/'shot_manifest_5min.json').read_text())['shots']
 actor_seconds=sum(s['end']-s['start'] for s in shot if s['actor']!='none')
 assert len(shot)==83 and abs(actor_seconds/300-.6507)<.01
 stamps=[1.3,4.8,8,11.5,16,21.1,26.9,31.2,35.5,43.6,49,53.2,58,62.2,66.5,72,75.7,79.2,83.4,88.6,96.2,101.3,110.7,116.4,120.8,130.1,139.9,146.8,153.2,160.1,169.2,176,184,191,200.4,211,219.3,224.4,231.3,238,245.5,253,261.5,270,282,291.6,296.2,299.4]
 cols,rows=8,6;contact=Image.new('RGB',(320*cols,220*rows),'#142135');draw=ImageDraw.Draw(contact)
 for i,t in enumerate(stamps):
  raw=subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-ss',str(t),'-i',str(RESULT),'-frames:v','1','-f','image2pipe','-vcodec','mjpeg','-'],timeout=80)
  assert raw[:2]==b'\xff\xd8'
  img=ImageOps.fit(Image.open(io.BytesIO(raw)).convert('RGB'),(320,190))
  x=(i%cols)*320;y=(i//cols)*220;contact.paste(img,(x,y+25));draw.text((x+9,y+5),f'{t:.1f}s',fill='white')
 contact.save(OUT/'RAIN_V4_CHARACTER_CORRECTED_5MIN_CONTACT.jpg',quality=90)
 report={'status':'TECHNICAL_PASS_CREATIVE_APPROVAL_REQUIRED','duration_seconds':float(q['format']['duration']), 'resolution':[1920,1080], 'fps':30,'frames':9000,'decoded_frames':9000,'video_codec':'h264','audio_codec':'aac','strict_monotonic_pts_dts':True,
  'sha256':sha(RESULT),'source_first120_sha256':MAN['approved_first120_sha256'],'original_first120_audio_preserved':True,
  'first120_video_explicitly_revised_for_character_presence':True,'character_presence_planned_seconds':actor_seconds,'character_presence_planned_share':actor_seconds/300,
  'source_artwork_reused_only':True,'new_paid_image_generations':0,'narration_provider':'kie.ai','model':'google/gemini-3-8-flash-tts','voice':'Fola','new_paid_tts_tasks':len(MAN['speech']['new_120to300']),'new_tts_credits':MAN['speech']['new_credits'],'prior_tts_credits':3.64,
  'total_known_tts_credits':3.64+MAN['speech']['new_credits'],'forced_paid_retries':0,'audio_word_level_alignment':'NOT_INDEPENDENTLY_VERIFIED',
  'normal_speed_audio_listening_review':'NOT_VERIFIED','user_visual_approval':'REQUIRED','render_shards':60,'asset_model_substitutions':0,'contact_sheet_frames':len(stamps)}
 (OUT/'RAIN_V4_CHARACTER_CORRECTED_5MIN_QA.json').write_text(json.dumps(report,indent=2)+'\n')
 (OUT/'RAIN_V4_CHARACTER_CORRECTED_5MIN_TIMELINE.json').write_text(json.dumps(MAN,indent=2)+'\n')
 print('FINAL_QA_PASS',json.dumps(report),flush=True)

def main():
 clips,voices,sfx=verify();v=picture(clips);soundtrack(v,voices,sfx);qa();v.unlink(missing_ok=True)
if __name__=='__main__':main()
