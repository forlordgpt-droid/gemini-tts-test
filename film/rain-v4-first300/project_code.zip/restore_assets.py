#!/usr/bin/env python3
"""Restore exact approved original-derived visual layers from fixed small Git blobs."""
from pathlib import Path
import json,hashlib,io,zipfile
root=Path('film/rain-v4-first300')
chunks=json.loads((root/'asset_chunks.json').read_text())
assets=json.loads((root/'asset_manifest.json').read_text())
assert len(chunks['parts'])==chunks['count']
b=bytearray()
for entry in chunks['parts']:
 p=root/'asset_parts'/entry['name']
 assert p.is_file(),p
 data=p.read_bytes()
 assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],p
 b.extend(data)
assert len(b)==chunks['total_bytes'] and hashlib.sha256(b).hexdigest()==chunks['zip_sha256']
with zipfile.ZipFile(io.BytesIO(b)) as z:
 assert z.testzip() is None
 expected={x['name']:x for x in assets['assets']}
 assert set(expected)==set(z.namelist()) and len(expected)>=70
 out=root/'scenes'/'assets';out.mkdir(parents=True,exist_ok=True)
 for name,entry in expected.items():
  assert name.endswith('.webp') and '/' not in name
  data=z.read(name)
  assert hashlib.sha256(data).hexdigest()==entry['sha256'] and len(data)==entry['bytes'],name
  (out/name).write_bytes(data)
print('PASS',len(expected),'approved static assets restored, all SHA-256 match, zero new image credits',flush=True)
