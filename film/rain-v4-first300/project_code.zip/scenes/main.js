import * as THREE from 'three';
import gsap from 'gsap';
// Canonical five-minute V4 character-led corrected edition.
// Human figures remain fixed illustrations; all human actions are implied through cuts.
// Only camera, environmental motion, typography, changing light, and nonhuman props animate.
const W=1920,H=1080,FPS=30,END=300,ASPECT=W/H;
const stage=document.getElementById('stage');
if(!stage||stage.width!==W||stage.height!==H)throw Error('Missing 1920x1080 V4 canvas');
const renderer=new THREE.WebGLRenderer({canvas:stage,alpha:false,antialias:true,preserveDrawingBuffer:true});
renderer.setPixelRatio(1);renderer.setSize(W,H,false);
renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.NoToneMapping;
renderer.autoClear=false;
const world=new THREE.Scene();world.background=new THREE.Color('#0c1a2b');
const camera=new THREE.PerspectiveCamera(55,ASPECT,.1,150);
const ui=new THREE.Scene(),uiCamera=new THREE.OrthographicCamera(-W/2,W/2,H/2,-H/2,.1,10);
uiCamera.position.z=5;
const response=await fetch('shot_manifest_5min.json');if(!response.ok)throw Error('Missing canonical shot plan');
const manifest=await response.json();const shots=manifest.shots;
if(shots.length!==83||shots[0].start!==0||shots.at(-1).end!==300)throw Error('Five-minute shot contract mismatch');
for(let i=1;i<shots.length;i++)if(Math.abs(shots[i].start-shots[i-1].end)>.001)throw Error('Noncanonical shot seam '+i);
const clamp=v=>Math.max(0,Math.min(1,v));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v)};
const rnd=i=>((Math.imul((i|0)+1851,1664525)+1013904223)>>>0)/4294967295;
function texture(im){const t=new THREE.Texture(im);t.needsUpdate=true;t.colorSpace=THREE.SRGBColorSpace;t.minFilter=THREE.LinearFilter;return t;}
function mat(t){return new THREE.MeshBasicMaterial({map:t,transparent:true,depthTest:false,depthWrite:false,toneMapped:false,side:THREE.DoubleSide});}
async function load(n){const im=new Image();im.src='assets/'+n+'.webp';await im.decode();return im;}
function plane(tex,z,order,overscan=1.225){
 const d=10-z,w=2*d*Math.tan(55*Math.PI/360)*ASPECT*overscan;
 const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,w/ASPECT),mat(tex));
 mesh.position.z=z;mesh.renderOrder=order;world.add(mesh);return mesh;
}
const artIds=['apartment','harbor','office','street','atmos','historic','flood','cold','tower','rope','market','stadium','corridor'];
const scenic={};
for(const id of artIds){
 const imgs=await Promise.all(['far','mid','front'].map(level=>load(`${id}_${level}`)));
 scenic[id]=[
  plane(texture(imgs[0]),-4.10,0,1.225),
  plane(texture(imgs[1]),-.75,1,1.225),
  plane(texture(imgs[2]),2.22,3,1.235)
 ];
}
const actorDefs={
 H1:['hero_day1_full'],H1C:['hero_day1_close'],
 H2:['hero_rain_full'],H2C:['hero_rain_close'],
 W:['walt_full'],WC:['walt_close_smile'],
 D:['hero_rain_full','walt_full'],C:['shopper_a','shopper_b']
};
const actorImageNames=[...new Set(Object.values(actorDefs).flat()),'walt_close_grave'];
const actors={};
for(const name of actorImageNames){
 const image=await load(name),m=new THREE.Mesh(new THREE.PlaneGeometry(image.width/image.height,1),mat(texture(image)));
 m.renderOrder=7;m.position.z=3.28;m.visible=false;world.add(m);actors[name]=m;
}
const propNames=['prop_phone','prop_laptop','prop_mug','prop_radio','prop_clock','rice','beans','oats','peanutbutter','canned_fish','salt','camp_stove','butane','bleach','duct_tape','matches','batteries','shopping_cart_left','shopping_cart_right','evac_bus','rope_intact','rope_broken','knife'];
const props={};
for(const name of propNames){
 const im=await load(name),m=new THREE.Mesh(new THREE.PlaneGeometry(im.width/im.height,1),mat(texture(im)));
 m.visible=false;m.renderOrder=8;m.position.z=3.42;world.add(m);props[name]=m;
}
// Dedicated depth layers for live environment, rain and independently moving water/object events.
const ambientCanvas=document.createElement('canvas');ambientCanvas.width=W;ambientCanvas.height=H;
const ag=ambientCanvas.getContext('2d',{alpha:true}),ambientTex=new THREE.CanvasTexture(ambientCanvas);
ambientTex.colorSpace=THREE.SRGBColorSpace;
const ambientPlane=plane(ambientTex,2.78,5,1.235);
const eventCanvas=document.createElement('canvas');eventCanvas.width=W;eventCanvas.height=H;
const eg=eventCanvas.getContext('2d',{alpha:true}),eventTex=new THREE.CanvasTexture(eventCanvas);
eventTex.colorSpace=THREE.SRGBColorSpace;
const eventPlane=plane(eventTex,3.69,10,1.235);
const graphicsCanvas=document.createElement('canvas');graphicsCanvas.width=W;graphicsCanvas.height=H;
const g=graphicsCanvas.getContext('2d',{alpha:true}),graphicsTex=new THREE.CanvasTexture(graphicsCanvas);
graphicsTex.colorSpace=THREE.SRGBColorSpace;
const graphicsMesh=new THREE.Mesh(new THREE.PlaneGeometry(W,H),mat(graphicsTex));
graphicsMesh.renderOrder=100;ui.add(graphicsMesh);
// GSAP owns the deterministic playhead and easing; no wall-clock animation or random frame state.
const playhead={fraction:0},timeline=gsap.timeline({paused:true});
for(const sh of shots){
 timeline.set(playhead,{fraction:0},sh.start);
 timeline.to(playhead,{fraction:1,duration:sh.end-sh.start,ease:'power2.inOut'},sh.start);
}
function cameraAt(sh,p){
 const i=Number(sh.id.slice(1)),move=sh.camera.toLowerCase();
 const close=move.includes('close')||move.includes('portrait')||move.includes('reaction');
 const sweep=move.includes('tracking')||move.includes('crane')||move.includes('pan')||move.includes('wide')||move.includes('sweep');
 const hold=move.includes('held')||move.includes('locked')||move.includes('frozen')||move.includes('still')||sh.id==='S083';
 const dir=(i%2===0?-1:1),delta=hold?.055:close?.25:sweep?.67:.44;
 const x0=-dir*(.27+.24*rnd(i+200));
 const y0=.11*(rnd(i+500)*2-1),z0=close?9.87:10.41;
 camera.position.set(x0+delta*p*dir,y0+(hold?0:(i%3===0?.22:-.18)*p),z0-(hold?.06:close?.23:sweep?.70:.43)*p);
 let tx=close?Math.sign(dir)*.08:0;
 camera.lookAt(new THREE.Vector3(tx+camera.position.x*.08,.03+Math.sin(p*Math.PI)*.05,0));
}
function setActor(name,x,y,h,z=3.28){
 const m=actors[name];if(!m)throw Error('Missing approved actor '+name);
 m.visible=true;const a=m.geometry.parameters.width/m.geometry.parameters.height;
 m.scale.set(h,h,1);m.position.set(x,y,z);m.rotation.set(0,0,0);
 return m;
}
function placeActors(sh){
 Object.values(actors).forEach(o=>o.visible=false);
 let count=0;
 const n=Number(sh.id.slice(1));
 const side=n%3===0?-1:1;
 if(sh.actor==='H1'||sh.actor==='H2'){
  setActor(sh.actor==='H1'?'hero_day1_full':'hero_rain_full',(n===24?3.87:side*3.33),-1.00,4.66);count=1;
 }else if(sh.actor==='H1C'||sh.actor==='H2C'){
  setActor(sh.actor==='H1C'?'hero_day1_close':'hero_rain_close',([20,25].includes(n)?3.80:side*3.24),-.45,3.42);count=1;
 }else if(sh.actor==='W'){
  setActor('walt_full',side*3.08,-.88,4.50);count=1;
 }else if(sh.actor==='WC'){
  setActor((n%2===0?'walt_close_grave':'walt_close_smile'),side*3.04,-.54,3.39);count=1;
 }else if(sh.actor==='D'){
  setActor('hero_rain_full',-3.10,-1.04,4.08);
  setActor('walt_full',3.25,-.98,4.05);count=2;
 }else if(sh.actor==='C'){
  setActor('shopper_a',-3.20,-1.00,4.48);setActor('shopper_b',3.08,-1.08,4.5);count=2;
 }else if(sh.actor!=='none')throw Error('Unexpected still actor config '+sh.actor);
 return count;
}
function setProp(name,x,y,height,z=3.4){
 const m=props[name];if(!m)throw Error('Missing approved prop '+name);
 m.visible=true;m.scale.set(height,height,1);m.position.set(x,y,z);m.rotation.set(0,0,0);return m;
}
function placeProps(sh,t){
 Object.values(props).forEach(x=>x.visible=false);
 const id=sh.id;
 if(id==='S017')setProp('prop_mug',-2.1,-1.6,1.1,3.72);
 if(id==='S016')setProp('prop_laptop',-1.78,-1.45,2.2,3.65);
 if(id==='S020')setProp('prop_phone',-1.5,-.85,1.65,3.65);
 if(id==='S026'||id==='S069')setProp('prop_radio',1.7,-1.22,2.0,3.73);
 if(id==='S080'||id==='S081')setProp('prop_clock',-2.3,-.78,2.4,3.65);
 if(id==='S056'||id==='S060')setProp('shopping_cart_left',-2.9,-1.75,2.45,3.50);
 if(id==='S059'||id==='S060')setProp('shopping_cart_right',2.65,-1.7,2.35,3.55);
 if(id==='S070'||id==='S071')setProp('evac_bus',1.10,-1.36,2.22,3.35);
 const items={'S047':['rice','beans','oats'],'S048':['peanutbutter','canned_fish'],'S049':['salt'],'S050':['camp_stove'],'S051':['butane'],'S052':['bleach'],'S053':['batteries','matches'],'S054':['duct_tape']};
 if(items[id]){
  const list=items[id];for(let j=0;j<list.length;j++)setProp(list[j],-2.8+j*2.0,-1.10,1.75,3.75);
 }
}
function rain(t,sh){
 ag.clearRect(0,0,W,H);
 const id=sh.art,indoor=['apartment','market','corridor','office'].includes(id),strong=['atmos','rope','flood','tower'].includes(id);
 const snow=id==='cold',seed=Number(sh.id.slice(1))*83;
 if(indoor){ag.save();ag.beginPath();if(id==='apartment')ag.rect(170,0,1300,670);else if(id==='market')ag.rect(930,95,535,720);else if(id==='corridor')ag.rect(690,145,550,550);else ag.rect(780,0,1050,840);ag.clip();}
 const count=snow?115:strong?190:indoor?60:140;
 const wind=snow?13:strong?-93:38;
 for(let k=0;k<count;k++){
  const d=rnd(k+seed+33),x=((rnd(k+seed+223)*2250+t*(wind*(.5+d))+8000)%2230)-140;
  const y=((rnd(k+seed+521)*1400+t*(snow?61:285)*(.60+d))%1380)-150;
  ag.globalAlpha=snow?.13+d*.25:indoor?.035+d*.07:.075+d*.21;
  if(snow){ag.fillStyle='#e0f1fd';ag.beginPath();ag.ellipse(x,y,2+d*3,1.2+d*2,0,0,Math.PI*2);ag.fill();}
  else{ag.strokeStyle=strong?'#bbd8e9':'#cfecf7';ag.lineWidth=.7+d*1.4;ag.lineCap='round';ag.beginPath();ag.moveTo(x,y);ag.lineTo(x+wind*.12,y+18+(strong?32:20)*d);ag.stroke();}
 }
 ag.globalAlpha=1;if(indoor)ag.restore();
 // Reflective water only where the story shows an exterior saturated plane.
 if(['flood','street','harbor','stadium'].includes(id)){
  for(let k=0;k<24;k++){
   const x=130+rnd(k+52)*1690,y=755+rnd(k+89)*270;
   const a=.035+.07*(.5+.5*Math.sin(t*2.1+k*1.7));
   ag.strokeStyle=`rgba(164,220,234,${a})`;ag.lineWidth=1.3;
   ag.beginPath();ag.ellipse(x,y,15+60*rnd(k+442),2.5,0,0,6.28);ag.stroke();
  }
 }
 if(sh.id==='S006'||sh.id==='S041'){
  const p=smooth((t-sh.start)/(sh.end-sh.start)),top=825-100*p;
  const water=ag.createLinearGradient(0,top,0,H);water.addColorStop(0,'rgba(100,176,190,0)');water.addColorStop(.13,'rgba(64,131,169,.13)');water.addColorStop(1,'rgba(15,60,78,.23)');
  ag.fillStyle=water;ag.fillRect(0,top,W,H-top);
 }
 ambientTex.needsUpdate=true;
}
function ropeAction(t,sh){
 if(!['S009','S010'].includes(sh.id))return;
 // Knife enters from offscreen, rope visibly changes state at 27.60s, no human motion.
 const intact=t<27.60;
 setProp(intact?'rope_intact':'rope_broken',0,-.22,1.05,3.8);
 if(t>=26&&t<29){
  const blade=setProp('knife',2.8-(smooth((t-26)/1.5))*2.1,-.28,1.65,4.0);
  blade.rotation.z=-.08*(smooth((t-26)/1.5));
 }
}
function environmentalEvent(t,sh){
 eg.clearRect(0,0,W,H);
 // Waterline and nonhuman ripples, falling droplets, radio rings, and phone state all survive WebGL export.
 if(sh.id==='S010'&&t>=27.60&&t<27.86){
  const p=1-(t-27.60)/.26;eg.save();eg.translate(1090,530);eg.strokeStyle=`rgba(250,221,168,${.5*p})`;eg.lineWidth=3;
  for(let i=0;i<12;i++){let a=i*6.283/12,r=20+(1-p)*46;eg.beginPath();eg.moveTo(0,0);eg.lineTo(Math.cos(a)*r,Math.sin(a)*r);eg.stroke();}eg.restore();
 }
 if(sh.id==='S017'){
  for(let i=0;i<5;i++){const y=630-((t*22+i*61)%210),x=1410+i*26+9*Math.sin(t+i);eg.strokeStyle='rgba(238,218,181,.13)';eg.lineWidth=8;eg.beginPath();eg.moveTo(x,y+22);eg.bezierCurveTo(x-17,y+2,x+22,y-8,x,y-30);eg.stroke();}
 }
 if(sh.id==='S025'){
  // The next page of the forecast scrolls without a visible hand.
  eg.fillStyle='rgba(155,227,248,.09)';eg.fillRect(180,125,1440,6);
 }
 if(['S070','S071','S082','S083'].includes(sh.id)){
  // Static crowd silhouettes: no figure is translated between frames.
  for(let i=0;i<30;i++){
   const x=190+i*48,y=760+Math.floor(i/10)*41,d=2.0+0.6*rnd(i);
   eg.fillStyle=`rgba(${50+Math.floor(35*rnd(i+61))},${72+Math.floor(35*rnd(i+90))},${87+Math.floor(38*rnd(i+24))},.48)`;
   eg.beginPath();eg.arc(x,y,5+d,0,Math.PI*2);eg.fill();
   eg.beginPath();eg.roundRect(x-6-d,y+7,12+d*2,20+d*5,4);eg.fill();
  }
 }
 eventTex.needsUpdate=true;
}
const font=(size,weight=700)=>`${weight} ${size}px Inter,system-ui,sans-serif`;
function pill(label,x,y,a=1,critical=false){
 a=clamp(a);if(a<=0)return;g.save();g.globalAlpha=a;g.font=font(25,730);
 const width=Math.min(1470,Math.max(240,g.measureText(label).width+58));
 g.fillStyle=critical?'rgba(80,25,32,.83)':'rgba(8,29,45,.75)';g.strokeStyle=critical?'rgba(248,136,113,.78)':'rgba(170,215,229,.50)';g.lineWidth=2;
 g.beginPath();g.roundRect(x,y,width,67,12);g.fill();g.stroke();g.fillStyle=critical?'#fbe5d6':'#e5f8fb';g.fillText(label,x+27,y+44);g.restore();
}
function headline(top,bottom,t,sh){
 const u=t-sh.start,d=sh.end-sh.start;
 const a=smooth(u/.43)*smooth((d-u)/.26);
 if(a<=0)return;
 g.save();g.globalAlpha=a;g.textAlign='center';g.shadowColor='rgba(2,10,20,.86)';g.shadowBlur=38;g.fillStyle='#f6ecdc';
 g.font=font(98,880);g.fillText(top,960,610);g.shadowBlur=0;g.fillStyle='#abd9e6';g.font=font(28,650);g.fillText(bottom,960,668);g.restore();
}
function drawRainIcon(x,y,scale=1){
 g.save();g.translate(x,y);g.scale(scale,scale);g.fillStyle='#e2eaf1';g.beginPath();g.arc(-18,0,15,0,6.283);g.arc(0,-15,23,0,6.283);g.arc(22,-1,18,0,6.283);g.roundRect(-34,-3,74,20,10);g.fill();
 g.lineWidth=3;g.strokeStyle='#8fd4eb';for(let i=-1;i<=1;i++){g.beginPath();g.moveTo(i*19-6,27);g.lineTo(i*19-17,46);g.stroke();}g.restore();
}
function forecast(t,second){
 const t0=second?77.3:73.9,u=t-t0;const x=70,y=145,w=1240,h=710;
 g.save();g.fillStyle='rgba(5,22,39,.86)';g.strokeStyle='rgba(170,219,233,.55)';g.lineWidth=2;
 g.beginPath();g.roundRect(x,y,w,h,31);g.fill();g.stroke();
 g.fillStyle='#f7fafc';g.font=font(40,800);g.fillText(second?'NEXT TEN DAYS':'TEN-DAY FORECAST',x+65,y+91);
 g.fillStyle='#b0d8e9';g.font=font(21,550);g.fillText('COASTAL CITY   /   DAILY OUTLOOK',x+68,y+135);
 for(let i=0;i<10;i++){
  const yy=Math.floor(i/5),xx=i%5;const px=x+48+xx*235,py=y+204+yy*231;
  g.globalAlpha=smooth((u-.10-i*.18)/.22);
  g.fillStyle='rgba(25,58,76,.84)';g.strokeStyle='rgba(144,215,233,.38)';g.lineWidth=2;g.beginPath();g.roundRect(px,py,214,196,17);g.fill();g.stroke();
  g.fillStyle='#e1eff5';g.font=font(20,680);g.fillText(`DAY ${i+1+(second?10:0)}`,px+24,py+42);
  drawRainIcon(px+107,py+94,.92);g.font=font(21,700);g.fillStyle='#b8dcea';g.fillText('RAIN',px+73,py+174);
 }
 g.restore();
}
function phoneAlert(t){
 const x=135,y=165,w=1080,h=635;g.save();g.fillStyle='rgba(4,22,42,.90)';g.strokeStyle='rgba(172,221,229,.62)';g.lineWidth=2;g.beginPath();g.roundRect(x,y,w,h,31);g.fill();g.stroke();
 g.fillStyle='#b4dff0';g.font=font(30,780);g.fillText('DAY TWO  /  EMERGENCY ALERT',x+75,y+96);
 const dismissed=t>=63.3;
 if(!dismissed){
  const pulse=.55+.45*Math.sin(t*11);g.fillStyle=`rgba(173,45,53,${.78+.19*pulse})`;g.beginPath();g.roundRect(x+70,y+153,w-140,248,24);g.fill();
  g.fillStyle='#fff0e6';g.font=font(74,880);g.fillText('FLOOD WATCH',x+116,y+290);g.font=font(29,620);g.fillText('Coastal and river areas',x+120,y+361);
  pill('DISMISS',x+110,y+472,1,false);
 }else{g.fillStyle='#d6e8f0';g.font=font(62,830);g.fillText('ALERT DISMISSED',x+110,y+299);g.font=font(26,560);g.fillText('The warning has been ignored.',x+117,y+364);}
 g.restore();
}
function shopping(t,sh){
 const id=Number(sh.id.slice(1)),u=t-sh.start,d=sh.end-sh.start;
 if(id>=47&&id<=55){
  // The approved physical prop illustration is independently placed in perspective.
  const a=smooth(u/.24)*smooth((d-u)/.22);
  const title=sh.graphic;
  pill('SUPPLY CHECKLIST  /  '+title,140,105,a,id===49);
 }
 if(id===56||id===57){headline('ONE CART','TEN MINUTES  ·  CHOOSE WHAT KEEPS YOU ALIVE',t,sh);}
 if(id===58||id===60){pill('TWO CARTS. TWO DIFFERENT PLANS.',150,105,smooth(u/.3));}
 if(id===62||id===63){pill(id===62?'“YOU’RE BUYING SOUP.”':'“I’M BUYING A BUILDING.”',145,730,a,true);}
}
function graph(t,sh){
 g.clearRect(0,0,W,H);const u=t-sh.start,d=sh.end-sh.start,n=Number(sh.id.slice(1));
 const vign=g.createRadialGradient(960,500,270,960,520,1180);vign.addColorStop(0,'rgba(5,14,26,0)');vign.addColorStop(1,'rgba(4,10,22,.41)');g.fillStyle=vign;g.fillRect(0,0,W,H);
 if(sh.art==='apartment'){
  const light=g.createRadialGradient(1410,260,30,1440,290,760);light.addColorStop(0,'rgba(251,197,105,.13)');light.addColorStop(1,'rgba(251,197,105,0)');g.fillStyle=light;g.fillRect(0,0,W,H);
 }
 if(sh.art==='historic')g.fillStyle='rgba(90,45,18,.10)',g.fillRect(0,0,W,H);
 const a=smooth(u/.24)*smooth((d-u)/.20);
 if(n===4)headline('10 YEARS','OF UNBROKEN RAIN',t,sh);
 else if(n===9||n===10){pill('YEAR SIX  /  FLASH FORWARD',118,105,a);if(t>27.6)headline('ON PURPOSE.','HE CUTS THE ROPE THAT KEPT HIM ALIVE',t,sh);}
 else if(n===24)forecast(t,false);
 else if(n===25)forecast(t,true);
 else if(n===20)phoneAlert(t);
 else if(n===29)headline('CALIFORNIA 1861','43 DAYS OF RAIN',t,sh);
 else if(n===30)headline('10 FEET','SACRAMENTO UNDER WATER',t,sh);
 else if(n===31)headline('INLAND SEA','THE CENTRAL VALLEY',t,sh);
 else if(n===35)headline('WHAT IF?','THE RAIN NEVER MOVES',t,sh);
 else if(n>=47&&n<=63)shopping(t,sh);
 else if(n===70)headline('EVACUATE','BUSES FROM THE STADIUM',t,sh);
 else if(n===71)headline('6:00 PM','THE FINAL BUS',t,sh);
 else if(n===74)headline('24 FLOORS','ELEVATORS CLOSED',t,sh);
 else if(n===77)headline('ONE MILE','THROUGH KNEE-DEEP FLOODWATER',t,sh);
 else if(n===78)headline('HIDDEN MANHOLES','A CURRENT YOU CANNOT SEE',t,sh);
 else if(n===81)headline('4:40 PM','LAST BUS 6:00 PM  ·  ONLY 80 MINUTES',t,sh);
 else if(n===82||n===83)headline('THE LINE','YOU WON’T REACH THE FRONT IN TIME',t,sh);
 else if(n===16){} // laptop scene reserved for unobstructed actor and approved prop
 else if(n===17){} // coffee detail must remain readable without giant text
 else pill(sh.graphic,110,92,a,n===3||n===19||n===49||n===69||n===73);
 // Story-accurate visual progress and dynamic graphics; never occlude faces.
 if(n===12){
  for(let k=0;k<30;k++){
   const y=180+k*19.2,active=k===23;
   g.fillStyle=active?'rgba(255,211,133,.83)':'rgba(184,224,231,.14)';g.fillRect(1735,y,44,9);
  }
 }
 if(n===28||n===34){
  g.save();g.globalAlpha=.49*a;g.strokeStyle='#a7dbe8';g.lineWidth=9;g.lineCap='round';g.beginPath();g.moveTo(280,781);g.bezierCurveTo(620,598,880,515,1580,293);g.stroke();g.restore();
 }
 if(n===65){pill('FLOOR 27',150,178,a,true);}
 if(n===73){pill('ELEVATORS OUT OF SERVICE',150,186,a,true);}
 if(n===75){pill('PACK / TEN MINUTES',155,174,a);}
 if(n===76){pill('STAIRS / FIFTEEN MINUTES',155,176,a);}
 if(n===79||n===80){pill(n===79?'ONE HOUR IF NOTHING GOES WRONG':'NINETY MINUTES AT BEST',154,185,a,true);}
 // A restrained series label keeps audiences oriented without competing with closeups.
 const footer=smooth(t/.45)*smooth((300-t)/.30);
 g.fillStyle=`rgba(175,218,235,${.32*footer})`;g.fillRect(115,1009,107,2);
 g.font=font(19,590);g.fillStyle=`rgba(225,236,242,${.72*footer})`;g.fillText('WHAT IF IT NEVER STOPPED RAINING?',114,1045);
 // Intentional editorial edge exposure, not fake actor vibration.
 const edge=Math.min(u,d-u),hit=(1-smooth(edge/.11))*.14;
 if(hit>0){g.fillStyle=`rgba(5,15,28,${hit})`;g.fillRect(0,0,W,H);}
 graphicsTex.needsUpdate=true;
}
window.renderFrame=async t=>{
 if(!Number.isFinite(t)||t<0||t>=END)throw Error('Outside canonical 300-second film '+t);
 const sh=shots.find(x=>t>=x.start&&t<x.end);if(!sh)throw Error('Time gap at '+t);
 timeline.seek(t,false);const p=playhead.fraction;cameraAt(sh,p);
 for(const [id,parts] of Object.entries(scenic))parts.forEach((m,i)=>{
  m.visible=id===sh.art;
  if(m.visible){m.position.x=i===0?0:i===1?.027*Math.sin(t*.42):.050*Math.sin(t*.53);m.position.y=i===2?.019*Math.sin(t*.9):0;}
 });
 const actorsVisible=placeActors(sh);placeProps(sh,t);ropeAction(t,sh);
 rain(t,sh);environmentalEvent(t,sh);graph(t,sh);
 renderer.clear();renderer.render(world,camera);renderer.clearDepth();renderer.render(ui,uiCamera);
 return {t,shot:sh.id,characters_visible:actorsVisible,actor_rule:'STILL',scene_art:sh.art,
  real_depth_planes:3,camera_x:camera.position.x,camera_z:camera.position.z,mode:sh.camera};
};
// Web Audio produces one fully deterministic 180s ambience + event-cue WAV for 120–300s.
window.exportRainSfx=async()=>{
 const rate=24000,seconds=180,n=rate*seconds,offline=new OfflineAudioContext(1,n,rate);
 const noise=offline.createBuffer(1,n,rate),data=noise.getChannelData(0);
 let seed=34199;for(let i=0;i<n;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;data[i]=(seed/4294967295*2-1)*.16;}
 const src=offline.createBufferSource();src.buffer=noise;
 const low=offline.createBiquadFilter();low.type='lowpass';low.frequency.value=1500;
 const gain=offline.createGain();gain.gain.value=.18;
 for(const [at,v] of [[0,.10],[17,.11],[30,.18],[45,.13],[70,.14],[95,.10],[118,.20],[130,.10],[147,.20],[165,.22],[178,.24],[180,.10]])gain.gain.linearRampToValueAtTime(v,at);
 src.connect(low);low.connect(gain);gain.connect(offline.destination);src.start();
 function hit(global,freq,volume,duration,kind='triangle'){
  const at=global-120;if(at<0||at>=seconds)return;
  const o=offline.createOscillator(),v=offline.createGain();o.type=kind;
  o.frequency.setValueAtTime(freq,at);o.frequency.exponentialRampToValueAtTime(Math.max(30,freq*.46),at+duration);
  v.gain.setValueAtTime(.0001,at);v.gain.exponentialRampToValueAtTime(volume,at+.02);v.gain.exponentialRampToValueAtTime(.0001,at+duration);
  o.connect(v);v.connect(offline.destination);o.start(at);o.stop(Math.min(180,at+duration+.005));
 }
 hit(143,70,.10,.48); // ankle-deep water, offscreen, not human motion
 hit(151,130,.14,.37); // supermarket offscreen metal noise
 hit(207,570,.07,.20,'sine'); // checkout electronic sound
 hit(222,56,.07,.6); // Walt dramatic shift
 hit(247,620,.10,.85,'sine'); // evacuation radio signal
 hit(262,72,.15,.53); // basement emergency elevator state
 hit(291,320,.08,.16,'sine'); // clock / decision
 hit(298,50,.13,1.0); // intimidating evacuation line
 const b=await offline.startRendering(),pcm=b.getChannelData(0),out=new ArrayBuffer(44+n*2),u8=new Uint8Array(out),v=new DataView(out);
 const chars=(offset,s)=>{for(let j=0;j<s.length;j++)u8[offset+j]=s.charCodeAt(j)};
 chars(0,'RIFF');v.setUint32(4,36+n*2,true);chars(8,'WAVEfmt ');v.setUint32(16,16,true);
 v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,rate,true);v.setUint32(28,rate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);
 chars(36,'data');v.setUint32(40,n*2,true);
 for(let i=0;i<n;i++)v.setInt16(44+i*2,Math.round(Math.max(-1,Math.min(1,pcm[i]))*32767),true);
 let str='';for(let i=0;i<u8.length;i+=8192)str+=String.fromCharCode(...u8.subarray(i,i+8192));
 return btoa(str);
};
await window.renderFrame(0);window.ready=true;
