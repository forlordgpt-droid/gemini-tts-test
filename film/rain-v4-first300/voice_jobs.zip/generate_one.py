#!/usr/bin/env python3
"""Exactly one authorized Kie Gemini 3.8 Flash Fola TTS request per approved segment.
No automatic retries, no model substitution, source WAV preserved unmodified.
"""
import argparse,hashlib,json,os,time,sys,math,wave,fcntl,urllib.request,urllib.parse,urllib.error
from pathlib import Path
API='https://api.kie.ai';MODEL='google/gemini-3-8-flash-tts'
def canonical(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def atom(path,obj):
 tmp=Path(str(path)+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');os.replace(tmp,path)
def request(path,body=None):
 key=os.getenv('KIE_API_KEY','').strip()
 if len(key)<16:raise RuntimeError('Missing KIE_API_KEY secret')
 headers={'Authorization':'Bearer '+key,'Accept':'application/json'}
 if body is not None:headers['Content-Type']='application/json'
 req=urllib.request.Request(API+path,headers=headers,data=json.dumps(body,ensure_ascii=False).encode() if body is not None else None,method='POST' if body is not None else 'GET')
 try:
  with urllib.request.urlopen(req,timeout=50) as r:resp=json.load(r)
 except Exception as e:raise RuntimeError('Provider request failed; preserve receipt; no paid retry: '+type(e).__name__) from None
 if resp.get('code')!=200:raise RuntimeError('Provider refused request code '+str(resp.get('code'))+'; no paid retry')
 return resp.get('data')
def validate(segment):
 base=Path(__file__).resolve().parent/segment
 req=json.loads((base/'request.json').read_text());auth=json.loads((base/'authorization.json').read_text())
 assert segment.startswith('s') and len(segment)==3 and segment[1:].isdigit()
 assert req.get('model')==MODEL
 inp=req['input'];assert inp['temperature']==1 and inp['filler_words'] is False
 assert inp['speakers']==[{'speaker_id':'Speaker 1','voice_name':'Fola'}]
 turns=inp['dialogue_turns'];assert len(turns)==1 and turns[0]['speaker_id']=='Speaker 1'
 text=turns[0]['text'];assert isinstance(text,str) and 30<len(text)<300
 assert 10<=len(text.split())<=62 and turns[0]['style']
 expected={'approved':True,'approval_scope':f'rain-v4-first300:tts-120to300-{segment}','provider':'kie.ai','model':MODEL,'jobs_authorized':1,'provider_hard_cap':False,'authorization_source':'current_conversation','request_sha256':canonical(req),'max_total_credits':1}
 for k,v in expected.items():
  if type(auth.get(k))!=type(v) or auth.get(k)!=v:raise RuntimeError('Authorization mismatch for '+k)
 if not str(auth.get('user_approval_evidence','')).strip():raise RuntimeError('Missing approval evidence')
 return base,req,auth,text
def analyze_wav(path):
 with wave.open(str(path),'rb') as w:
  spec=(w.getframerate(),w.getnchannels(),w.getsampwidth(),w.getcomptype())
  if spec!=(24000,1,2,'NONE'):raise RuntimeError('Wrong provider WAV format '+repr(spec))
  dur=w.getnframes()/w.getframerate()
 assert dur>0
 return {'duration_seconds':dur,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sample_rate':24000,'channels':1,'bit_depth':16,'source_modified':False}
def main():
 p=argparse.ArgumentParser();p.add_argument('--segment',required=True);p.add_argument('--out',default='tts_out');p.add_argument('--validate-only',action='store_true');a=p.parse_args()
 base,req,auth,text=validate(a.segment)
 if a.validate_only:
  print(json.dumps({'segment':a.segment,'model':MODEL,'voice':'Fola','words':len(text.split()),'request_sha256':canonical(req),'paid_calls':0}));return
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 wav=out/f'RAIN_V4_FIRST300_{a.segment.upper()}_FOLA.wav'
 receipt=out/'TASK_RECEIPT.json'
 with (out/'.process.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if receipt.exists():
   r=json.loads(receipt.read_text())
   if r.get('request_sha256')!=canonical(req):raise RuntimeError('Existing receipt mismatch; no paid retry')
   if wav.exists():
    info=analyze_wav(wav)
    if info['sha256']==r.get('audio',{}).get('sha256'):
     print('Already complete; no paid calls');return
   if not r.get('task_id'):raise RuntimeError('Existing submission outcome unknown; no resubmission')
  else:
   if os.getenv('GITHUB_ACTIONS')!='true' or os.getenv('GITHUB_RUN_NUMBER')!='1' or os.getenv('GITHUB_RUN_ATTEMPT')!='1':raise RuntimeError('New paid request only allowed in first run, first attempt')
   credits=float(request('/api/v1/chat/credit'))
   if not math.isfinite(credits) or credits<1:raise RuntimeError('Insufficient credits for conservative one-task local guard')
   r={'model':MODEL,'voice':'Fola','segment':a.segment,'state':'SUBMISSION_INTENT','request_sha256':canonical(req),'local_max_credits_estimate':1,'provider_hard_cap':False,'created_at':time.time(),'auto_paid_retry':False}
   atom(receipt,r)
   try:
    response=request('/api/v1/jobs/createTask',req)
    task_id=response.get('taskId') if isinstance(response,dict) else None
    if not task_id:raise RuntimeError('Kie did not return taskId')
   except Exception:
    r['state']='CREATE_OUTCOME_UNKNOWN';atom(receipt,r);raise
   r['task_id']=task_id;r['state']='SUBMITTED';atom(receipt,r)
  deadline=time.monotonic()+780
  while time.monotonic()<deadline:
   info=request('/api/v1/jobs/recordInfo?'+urllib.parse.urlencode({'taskId':r['task_id']}))
   if not isinstance(info,dict):raise RuntimeError('Malformed task status')
   if info.get('model') and info['model']!=MODEL:raise RuntimeError('Wrong provider model')
   state=info.get('state');r['provider_state']=state
   if info.get('creditsConsumed') is not None:r['credits_consumed']=float(info['creditsConsumed'])
   if state=='fail':r['state']='FAILED';atom(receipt,r);raise RuntimeError('Provider task failed; no retry')
   if state=='success':r['state']='SUCCEEDED_PENDING_DOWNLOAD';atom(receipt,r);break
   if state not in ('waiting','queuing','generating'):raise RuntimeError('Unexpected provider state')
   r['state']='PENDING';atom(receipt,r);time.sleep(4)
  else:raise RuntimeError('Provider task pending; preserve receipt, do not regenerate')
  data=info.get('resultJson') or info.get('response') or {}
  if isinstance(data,str):data=json.loads(data)
  urls=data.get('resultUrls') if isinstance(data,dict) else []
  if not urls:raise RuntimeError('No audio result URL for completed task')
  u=urls[0];assert urllib.parse.urlparse(u).scheme=='https'
  with urllib.request.urlopen(u,timeout=100) as f:b=f.read(16000000+1)
  if len(b)>16000000 or b[:4]!=b'RIFF' or b[8:12]!=b'WAVE':raise RuntimeError('Provider returned invalid WAV')
  wav.write_bytes(b)
  r['audio']=analyze_wav(wav);r['state']='SUCCEEDED';atom(receipt,r)
  atom(out/'NARRATION_AUDIT.json',{'model':MODEL,'voice':'Fola','segment':a.segment,'words':len(text.split()),'text':text,'request_sha256':canonical(req),'provider_task_id':r['task_id'],'credits_consumed':r.get('credits_consumed'),'audio':r['audio'],'paid_task_creation_attempts':1,'additional_paid_retries':0})
  print(json.dumps({'state':'SUCCEEDED','segment':a.segment,'audio':r['audio'],'credits_consumed':r.get('credits_consumed')}))
if __name__=='__main__':
 try:main()
 except Exception as e:
  print('STOP:',str(e) if isinstance(e,(RuntimeError,AssertionError)) else type(e).__name__,file=sys.stderr);sys.exit(1)
